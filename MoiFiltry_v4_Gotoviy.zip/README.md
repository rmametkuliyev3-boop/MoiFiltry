# Мои Фильтры v4
Минимальный Android-проект для приложения «Мои Фильтры». Структура подготовлена для GitHub Actions.

Обязательные файлы проверки присутствуют:
- settings.gradle
- build.gradle
- app/build.gradle
- app/src/main/AndroidManifest.xml
- app/src/main/java/kz/moifiltry/app/MainActivity.java
- app/src/main/assets/index.html
