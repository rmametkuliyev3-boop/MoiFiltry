package kz.moifiltry.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private String pendingBackup;
    private SharedPreferences backupPrefs;
    private static final int REQ_BACKUP_FILE = 100;
    private static final int REQ_RESTORE_FILE = 101;
    private static final int REQ_BACKUP_FOLDER = 102;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        backupPrefs = getSharedPreferences("backup_settings", MODE_PRIVATE);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void backup(String json) {
            pendingBackup = json;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "MoiFiltry_backup.json");
            startActivityForResult(intent, REQ_BACKUP_FILE);
        }

        @JavascriptInterface
        public void chooseBackupFolder() {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            startActivityForResult(intent, REQ_BACKUP_FOLDER);
        }

        @JavascriptInterface
        public boolean hasBackupFolder() {
            return !backupPrefs.getString("backup_tree_uri", "").isEmpty();
        }

        @JavascriptInterface
        public void autoBackup(String json) {
            String uriString = backupPrefs.getString("backup_file_uri", "");
            if (uriString.isEmpty()) return;
            try {
                Uri uri = Uri.parse(uriString);
                OutputStream out = getContentResolver().openOutputStream(uri, "wt");
                if (out == null) throw new IllegalStateException("backup output unavailable");
                out.write(json.getBytes("UTF-8"));
                out.close();
                return;
            } catch (Exception ignored) { }
            try {
                String treeString = backupPrefs.getString("backup_tree_uri", "");
                if (treeString.isEmpty()) return;
                Uri fileUri = findOrCreateBackupFile(Uri.parse(treeString));
                if (fileUri == null) return;
                OutputStream out = getContentResolver().openOutputStream(fileUri, "wt");
                if (out == null) return;
                out.write(json.getBytes("UTF-8"));
                out.close();
                backupPrefs.edit().putString("backup_file_uri", fileUri.toString()).apply();
            } catch (Exception ignored) {
                // Automatic backup must never interrupt normal app work.
            }
        }

        @JavascriptInterface
        public void restore() {
            String treeString = backupPrefs.getString("backup_tree_uri", "");
            if (!treeString.isEmpty()) {
                if (restoreLatestFromFolder(Uri.parse(treeString))) return;
            }
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("application/json");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, REQ_RESTORE_FILE);
        }

        @JavascriptInterface
        public void call(String phone) {
            String digits = phone.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + digits)));
        }

        @JavascriptInterface
        public void whatsapp(String phone) {
            String digits = phone.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digits)));
        }

        @JavascriptInterface
        public void openMapChooser(String address) {
            final String safe = address == null ? "" : address.trim();
            if (safe.isEmpty()) return;
            final String[] names = {"2ГИС", "Яндекс Карты"};
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Открыть адрес в")
                    .setItems(names, (dialog, which) -> openMap(which == 0 ? "2gis" : "yandex", safe))
                    .setNegativeButton("Отмена", null)
                    .show();
        }

        private void openMap(String provider, String address) {
            try {
                String encoded = Uri.encode(address);
                String url;
                String packageName;
                if ("2gis".equals(provider)) {
                    url = "https://2gis.kz/almaty/search/" + encoded;
                    packageName = "ru.dublgis.dgismobile";
                } else {
                    url = "https://yandex.kz/maps/?text=" + encoded;
                    packageName = "ru.yandex.yandexmaps";
                }
                Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                appIntent.setPackage(packageName);
                try { startActivity(appIntent); }
                catch (Exception notInstalled) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            } catch (Exception ignored) { }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("typeof handleAndroidBack==='function' ? handleAndroidBack() : 'exit'", value -> {
                if ("\"exit\"".equals(value)) finish();
            });
        } else super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        try {
            if (requestCode == REQ_BACKUP_FILE) {
                OutputStream out = getContentResolver().openOutputStream(data.getData());
                if (out != null) {
                    out.write((pendingBackup == null ? "" : pendingBackup).getBytes("UTF-8"));
                    out.close();
                }
            } else if (requestCode == REQ_BACKUP_FOLDER) {
                Uri treeUri = data.getData();
                int takeFlags = data.getFlags() &
                        (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try { getContentResolver().takePersistableUriPermission(treeUri, takeFlags); } catch (Exception ignored) { }
                Uri fileUri = findOrCreateBackupFile(treeUri);
                if (fileUri != null) {
                    backupPrefs.edit()
                            .putString("backup_tree_uri", treeUri.toString())
                            .putString("backup_file_uri", fileUri.toString())
                            .apply();
                    webView.evaluateJavascript("autoBackupNow()", null);
                }
            } else if (requestCode == REQ_RESTORE_FILE) {
                InputStream in = getContentResolver().openInputStream(data.getData());
                BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                StringBuilder json = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) json.append(line);
                reader.close();
                String safeJson = org.json.JSONObject.quote(json.toString());
                webView.evaluateJavascript("restoreBackup(" + safeJson + ")", null);
            }
        } catch (Exception e) {
            webView.evaluateJavascript("alert('Не удалось выполнить операцию с резервной копией');", null);
        }
    }

    private boolean restoreLatestFromFolder(Uri treeUri) {
        Uri children;
        try {
            children = DocumentsContract.buildChildDocumentsUriUsingTree(
                    treeUri, DocumentsContract.getTreeDocumentId(treeUri));
        } catch (Exception e) {
            return false;
        }
        Uri bestUri = null;
        long bestTime = Long.MIN_VALUE;
        try (android.database.Cursor cursor = getContentResolver().query(
                children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE,
                        DocumentsContract.Document.COLUMN_LAST_MODIFIED},
                null, null, null)) {
            if (cursor == null) return false;
            int idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
            int modifiedCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
            while (cursor.moveToNext()) {
                String name = nameCol >= 0 ? cursor.getString(nameCol) : "";
                String mime = mimeCol >= 0 ? cursor.getString(mimeCol) : "";
                if (!(name.toLowerCase(java.util.Locale.ROOT).endsWith(".json") || "application/json".equalsIgnoreCase(mime))) continue;
                String id = cursor.getString(idCol);
                Uri fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                long fallback = modifiedCol >= 0 && !cursor.isNull(modifiedCol) ? cursor.getLong(modifiedCol) : 0L;
                long savedAt = readBackupSavedAt(fileUri, fallback);
                if (savedAt > bestTime) {
                    bestTime = savedAt;
                    bestUri = fileUri;
                }
            }
        } catch (Exception ignored) {
            return false;
        }
        if (bestUri == null) return false;
        try {
            String json = readText(bestUri);
            if (json.isEmpty()) return false;
            String safeJson = JSONObject.quote(json);
            webView.evaluateJavascript("restoreBackup(" + safeJson + ")", null);
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private long readBackupSavedAt(Uri fileUri, long fallback) {
        try {
            String json = readText(fileUri);
            JSONObject obj = new JSONObject(json);
            String savedAt = obj.optString("savedAt", "");
            if (!savedAt.isEmpty()) {
                try { return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX", Locale.US).parse(savedAt).getTime(); }
                catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return fallback;
    }

    private String readText(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) return "";
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            StringBuilder text = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) text.append(line);
            return text.toString();
        }
    }

    private Uri findOrCreateBackupFile(Uri treeUri) {
        try {
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(
                    treeUri, DocumentsContract.getTreeDocumentId(treeUri));
            try {
                android.database.Cursor cursor = getContentResolver().query(
                        children,
                        new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME},
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME + "=?",
                        new String[]{"MoiFiltry_backup.json"},
                        null);
                if (cursor != null) {
                    try {
                        if (cursor.moveToFirst()) {
                            String id = cursor.getString(0);
                            return DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                        }
                    } finally { cursor.close(); }
                }
            } catch (Exception ignored) { }
            return DocumentsContract.createDocument(getContentResolver(), treeUri, "application/json", "MoiFiltry_backup.json");
        } catch (Exception e) {
            return null;
        }
    }
}
