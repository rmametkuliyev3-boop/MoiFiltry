package kz.moifiltry.app;
import android.app.*;import android.os.*;import android.webkit.*;import android.content.*;import android.net.Uri;import java.io.*;
public class MainActivity extends Activity{
 WebView w; String pending;
 public void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);w.addJavascriptInterface(new B(),"Android");w.loadUrl("file:///android_asset/index.html");setContentView(w);}
 class B{@JavascriptInterface public void backup(String s){pending=s;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"MoiFiltry_backup.json");startActivityForResult(i,1);}
 @JavascriptInterface public void restore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,2);}
 @JavascriptInterface public void whatsapp(String p){startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+p.replaceAll("[^0-9]",""))));}}
 protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);try{if(c!=RESULT_OK)return;if(r==1){OutputStream o=getContentResolver().openOutputStream(d.getData());o.write(pending.getBytes("UTF-8"));o.close();w.evaluateJavascript("alert('Резервная копия сохранена');",null);}else{InputStream i=getContentResolver().openInputStream(d.getData());BufferedReader br=new BufferedReader(new InputStreamReader(i));StringBuilder s=new StringBuilder(),x;while((x=br.readLine())!=null)s.append(x);br.close();w.evaluateJavascript("restoreBackup("+org.json.JSONObject.quote(s.toString())+")",null);}}catch(Exception e){w.evaluateJavascript("alert('Ошибка');",null);}}
}
