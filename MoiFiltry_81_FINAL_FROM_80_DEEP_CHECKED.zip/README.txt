MoiFiltry 8.1 — источник проекта

Версия проекта: 8.1, applicationId kz.moifiltry.app.v81.
База изменений: MoiFiltry 80.
