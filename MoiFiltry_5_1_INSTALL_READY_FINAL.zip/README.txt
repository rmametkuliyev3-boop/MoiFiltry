MoiFiltry 5.1 — installation-ready Android project.

Important: GitHub Actions artifacts are ZIP files. For direct APK installation,
use the APK attached to the GitHub Actions run's Release section, or extract
the artifact ZIP first and install the .apk file inside it.

Application ID: kz.moifiltry.app51
Version: 5.1 (versionCode 8)
