# MoiFiltry 5.1 — no custom shrinking rules required.
