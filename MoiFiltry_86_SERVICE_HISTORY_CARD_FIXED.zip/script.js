const KEY='moifiltry5';
let db=JSON.parse(localStorage.getItem(KEY)||'null');
if(!db) db={clients:[],nextClientNumber:1};
if(!Array.isArray(db.clients)) db.clients=[];
// 5.1: remove legacy fields that are no longer used in the interface.
db.clients.forEach(c=>{delete c.mineralizer;delete c.postfilter;delete c.pp100;c.extraPhones=(Array.isArray(c.extraPhones)?c.extraPhones:[]).map(p=>typeof p==='string'?{name:'',phone:p}:{name:String(p?.name||''),phone:String(p?.phone||'')}).filter(p=>p.phone||p.name);});
function normalizeServiceHistoryData(){
 db.clients.forEach(c=>{
  if(!Array.isArray(c.serviceHistory))c.serviceHistory=[];
  let history=c.serviceHistory.filter(h=>h&&h.date);
  const installDate=String(c.install||'');
  // Дата установки никогда не является записью обслуживания.
  history=history.filter(h=>String(h.date)!==installDate);
  const legacyActual=String(c.lastReplacementDate||'');
  if(!history.length&&legacyActual&&legacyActual!==installDate){
   history.push({date:legacyActual,nextDate:String(c.replace||''),plannedDate:'',items:(c.cartridges||[]).map(part=>({part,brand:'Не указан'})),comment:'',completed:true,migrated:true});
  }
  const completed=Array.isArray(c.completedDates)?c.completedDates:[];
  completed.forEach(ds=>{const d=String(ds||'');if(d&&d!==installDate&&!history.some(h=>h.date===d&&h.completed===true))history.push({date:d,nextDate:'',plannedDate:d,items:[],comment:'',completed:true,migrated:true});});
  history.sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
  c.serviceHistory=history;
  delete c.lastReplacementDate;
  delete c.completedDates;
 });
}
normalizeServiceHistoryData();
if(!Number.isInteger(db.nextClientNumber)||db.nextClientNumber<1) db.nextClientNumber=(db.clients.reduce((m,c)=>Math.max(m,Number(c.number)||0),0)+1);
let month=new Date();month.setDate(1);
let homeSearchOpen=false;
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const save=()=>localStorage.setItem(KEY,JSON.stringify(db));
const models=['Ecosoft с насосом','Ecosoft без насоса','FitAqua с насосом','FitAqua без насоса','Другое'];
const cartridges=['PP5','GAC','CTO','PP1','Пост-фильтр','Минерализатор','RO-мембрана'];
const brands=['Вастерлайн','Ecosoft','FitAqua'];
function hideHomeCounters(){}
function toggleMenu(){document.getElementById('menu').classList.toggle('open')}
function closeMenu(){document.getElementById('menu').classList.remove('open')}
function todayISO(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function ruDate(ds){if(!ds)return '—';const [y,m,d]=ds.split('-');return `${d}.${m}.${y}`}
function initTopDate(){document.getElementById('topDate').textContent='📅 '+ruDate(todayISO());}
function openTopCalendar(){calendar();}
function addMonthsISO(ds,months){if(!ds)return '';const d=new Date(ds+'T12:00:00');if(Number.isNaN(d.getTime()))return '';const day=d.getDate();d.setMonth(d.getMonth()+Number(months||0));if(d.getDate()!==day)d.setDate(0);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function serviceHistorySorted(c){return Array.isArray(c?.serviceHistory)?c.serviceHistory.filter(h=>h&&h.date).slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))):[]}
function lastService(c){const h=serviceHistorySorted(c);return h.length?h[h.length-1]:null}
function replacementBaseDate(c){return lastService(c)?.date||c?.install||''}
function isPlannedCompleted(c,plannedDate){if(!plannedDate)return false;return serviceHistorySorted(c).some(h=>h.completed===true&&(h.plannedDate===plannedDate||h.date===plannedDate))}
function isDue(c){const t=todayISO();return !!(c.replace&&c.replace<=t&&!isPlannedCompleted(c,c.replace))}
function isOverdue(c){const t=todayISO();return !!(c.replace&&c.replace<t&&!isPlannedCompleted(c,c.replace))}
function firstService(c){const h=serviceHistorySorted(c);return h.length?h[0]:null}
function updateHomeCounters(){
 const box=document.getElementById('homeCounters');
 if(!box)return;
 const t=todayISO();
 const todayCount=db.clients.filter(c=>c.replace===t&&!isPlannedCompleted(c,c.replace)).length;
 const overdueCount=db.clients.filter(isOverdue).length;
 document.getElementById('todayCounter').textContent=todayCount;
 document.getElementById('overdueCounter').textContent=overdueCount;
}
function toggleHomeSearch(){
 if(!app.innerHTML.includes('id="homeSearch"')){filterHome();homeSearchOpen=true;filterHome();}
 else {homeSearchOpen=!homeSearchOpen;filterHome();}
}

function clients(){
 setScreen('clients'); setShell('filters');
 const q=(document.getElementById('search')?.value||'').toLowerCase();
 const arr=db.clients.filter(c=>[c.name,c.phone,c.address,c.addressExtra,c.model,String(c.number),(c.extraPhones||[]).map(p=>typeof p==='string'?p:(p.name+' '+p.phone)).join(' ')].join(' ').toLowerCase().includes(q));
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">Клиентская база</div><div class="stat">${db.clients.length}</div><div class="muted">Всего клиентов</div></div><div><button type="button" class="secondary" onclick="home()">Назад</button><button onclick="newClient()">+ Новый клиент</button></div></div></div>
 <div class="card"><input id="search" class="search" placeholder="Поиск клиента: имя, телефон, адрес или №" value="${esc(q)}" oninput="clients()"></div>`+
 (arr.length?arr.map(c=>`<div class="card client" onclick="editClientByNumber(${c.number})"><div class="row"><b>№${c.number} — ${esc(c.name)||'Без имени'}</b><span class="muted">${esc(formatPhoneDisplay(c.phone))}</span></div><div>${c.model?`<span class=pill>${esc(c.model)}</span>`:''}${(c.cartridges||[]).map(x=>`<span class=pill>${esc(x)}</span>`).join('')}</div><div class="muted">🏠 ${esc(c.address)||'Адрес не указан'}${c.addressExtra?` · ${esc(c.addressExtra)}`:''}</div><div class="muted">Установка: ${c.install?ruDate(c.install):'—'} · Следующая замена: ${c.replace?ruDate(c.replace):'—'}</div></div>`).join(''):`<div class="card empty">Ничего не найдено.</div>`);
}
function filterHome(){
 setScreen('filterHome'); setShell('filters');
 const today=todayISO();
 const todayTasks=db.clients.filter(c=>c.replace===today&&!isPlannedCompleted(c,c.replace));
 const overdue=db.clients.filter(isOverdue);
 app.innerHTML=`${homeSearchOpen?`<div class="card"><input id="homeSearch" class="search" placeholder="Поиск клиента" oninput="homeSearch()" autofocus></div><div id="homeResults"></div>`:''}${todayTasks.length?`<div class="card"><div class="sectionTitle">Заявки на сегодня</div>${todayTasks.map(c=>`<div class="list"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">Плановая замена: ${ruDate(c.replace)}${c.install?` · Установка: ${ruDate(c.install)}`:''}</div></div></div>`).join('')}</div>`:''}`;
 const counters=document.getElementById('homeCounters');
 if(counters)counters.classList.add('open');
 updateHomeCounters();
}
function homeSearch(){const q=(document.getElementById('homeSearch')?.value||'').toLowerCase();const box=document.getElementById('homeResults');if(!box)return;if(!q){box.innerHTML='';return;}const arr=db.clients.filter(c=>[c.name,c.phone,c.address,c.addressExtra,c.model,String(c.number),(c.extraPhones||[]).map(p=>typeof p==='string'?p:(p.name+' '+p.phone)).join(' ')].join(' ').toLowerCase().includes(q));box.innerHTML=arr.length?`<div class="card">${arr.map(c=>`<div class="list" onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)||'Без имени'}</b><div class="muted">${esc(formatPhoneDisplay(c.phone))} · ${esc(c.address)||'Адрес не указан'}${c.addressExtra?` · ${esc(c.addressExtra)}`:''}</div></div>`).join('')}</div>`:'<div class="card empty">Клиент не найден.</div>'}
function showOverdue(){
 setScreen('overdue');const arr=db.clients.filter(isOverdue);app.innerHTML=`<div class="card"><div class="row"><div class="sectionTitle">Просроченные</div><button type="button" class="secondary" onclick="home()">Назад</button></div>${arr.length?arr.map(c=>`<div class="list"><div class="row"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">Плановая замена: ${ruDate(c.replace)}${lastService(c)?` · Последняя замена: ${ruDate(lastService(c).date)}`:''}</div></div><button class="small" onclick="completeTask(${c.number},'${c.replace}')">Выполнено</button></div></div>`).join(''):'<div class="empty">Просроченных заявок нет.</div>'}</div>`}
function completeCurrentTask(i){const c=db.clients[i];if(!c||!c.replace)return;completeTask(c.number,c.replace)}
function completeTask(n,plannedDate){
 const i=getIndexByNumber(n);if(i<0)return;
 const c=db.clients[i];
 if(!c||!plannedDate)return;
 if(isPlannedCompleted(c,plannedDate))return;
 const nextDefault=addMonthsISO(plannedDate,6);
 const next=prompt('Дата следующей замены:',nextDefault)||'';
 if(!Array.isArray(c.serviceHistory))c.serviceHistory=[];
 const known={};
 c.serviceHistory.forEach(h=>(h.items||[]).forEach(x=>{if(x.part&&x.brand)known[x.part]=x.brand;}));
 const items=(c.cartridges||[]).map(part=>({part,brand:known[part]||'Не указан'}));
 c.serviceHistory.push({date:plannedDate,nextDate:next,plannedDate,items,comment:'',completed:true});
 c.serviceHistory.sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 c.replace=next;
 delete c.lastReplacementDate;
 delete c.completedDates;
 save();filterHome();
}

function getIndexByNumber(n){return db.clients.findIndex(c=>Number(c.number)===Number(n))}
function editClientByNumber(n){editClient(getIndexByNumber(n))}
function phoneDigits(value){
 let d=String(value||'').replace(/\D/g,'');
 if(d.startsWith('00')) d=d.slice(2);
 if(d.startsWith('7') && d.length===11) d='8'+d.slice(1);
 if(d.startsWith('8')) return d.slice(0,11);
 return d.slice(0,11);
}
function phoneLocal(value){return phoneDigits(value)}
function formatPhoneField(el){
 const d=phoneDigits(el.value);
 let out=d;
 if(d.length>1) out=d.slice(0,1)+' '+d.slice(1);
 if(d.length>4) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4);
 if(d.length>7) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7);
 if(d.length>9) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7,9)+' '+d.slice(9,11);
 el.value=out;
}
function formatPhoneDisplay(value){
 const d=phoneDigits(value);
 if(!d) return '';
 let out=d;
 if(d.length>1) out=d.slice(0,1)+' '+d.slice(1);
 if(d.length>4) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4);
 if(d.length>7) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7);
 if(d.length>9) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7,9)+' '+d.slice(9,11);
 return out;
}
function phoneIcon(type){
 if(type==='wa') return '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#fff" d="M20.5 3.5A11.4 11.4 0 0 0 12.4 0C6.1 0 1 5.1 1 11.4c0 2 .5 4 1.5 5.7L.9 23l6-1.6a11.3 11.3 0 0 0 5.5 1.4h.1C18.8 22.8 24 17.7 24 11.4c0-3-1.2-5.8-3.5-7.9Zm-8.1 17.3h-.1c-1.7 0-3.4-.5-4.8-1.3l-.3-.2-3.5.9.9-3.4-.2-.3a9.4 9.4 0 1 1 8 4.3Zm5.2-7.1c-.3-.2-1.7-.8-2-.9-.3-.1-.5-.2-.7.2-.2.3-.8.9-.9 1.1-.2.2-.3.2-.6.1-1.5-.7-2.5-1.3-3.5-2.9-.3-.5.3-.4.8-1.4.1-.2.1-.4 0-.6-.1-.2-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.2 1.1-1.2 2.7s1.2 3.1 1.4 3.3c.2.2 2.3 3.5 5.6 4.9 2.1.9 2.1.6 2.5.6.4 0 1.7-.7 2-1.3.2-.6.2-1.1.1-1.2-.1-.1-.3-.2-.6-.3Z"/></svg>';
 return '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#fff" d="M6.6 2.2 8.9 2c.5 0 .9.3 1.1.7l1.3 3.1c.2.4.1.9-.2 1.2L9.7 7.8c.8 1.7 2.1 3.1 3.8 3.9l.8-1.4c.3-.4.7-.5 1.2-.3l3.1 1.3c.4.2.7.6.7 1.1l-.2 2.3c-.1.8-.8 1.5-1.6 1.6-.6.1-1.2.1-1.8 0-5.9-.9-10.5-5.5-11.4-11.4-.1-.6-.1-1.2 0-1.8.1-.8.8-1.5 1.6-1.6Z"/></svg>';
}
function contactActions(phone, index, extra){
 const p=phoneDigits(phone||'');
 if(p.length!==11) return '';
 const callFn=extra ? `callExtraContact(${index})` : `callPhoneValue('${p}')`;
 const waFn=extra ? `waExtraContact(${index})` : `waPhoneValue('${p}')`;
 return `<div class="contactActions"><button type="button" class="contactIcon callIcon" onclick="${callFn}" aria-label="Позвонить">${phoneIcon('call')}</button><button type="button" class="contactIcon waIcon" onclick="${waFn}" aria-label="WhatsApp">${phoneIcon('wa')}</button></div>`;
}
function form(i){
 setScreen('client'); setShell('filters');
 const c=i<0?{number:db.nextClientNumber,name:'',phone:'',extraPhones:[],address:'',addressExtra:'',model:'Ecosoft с насосом',cartridges:[],install:'',replace:'',notes:'',serviceHistory:[]}:db.clients[i];
 if(!Array.isArray(c.serviceHistory))c.serviceHistory=[];
 const addressBlock=c.address?`<div class="addressRow"><button type="button" class="addressLink" onclick="chooseMap(${i})">🏠 ${esc(c.address)}</button><button type="button" class="secondary small addressEdit" onclick="editAddressField(${i})">Изменить</button></div>`:`<input id="address" value="" placeholder="Адрес клиента">`;
 const extraContacts=(c.extraPhones||[]).map((p,idx)=>{const obj=typeof p==='string'?{name:'',phone:p}:(p||{});return extraPhoneHtml(obj.phone||'',idx,obj.name||'');}).join('');
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">${i<0?'Новый клиент':'Карточка клиента'}</div><div class="muted">№${c.number}</div></div><button type="button" class="secondary" onclick="clients()">Назад</button></div>
 <label>Основной контакт</label><div class="contactBlock"><div class="contactName"><input id="name" value="${esc(c.name)}" placeholder="Имя и фамилия"></div><div class="contactPhoneRow"><div class="phoneInputWrap"><input id="phone" inputmode="numeric" maxlength="15" value="${esc(phoneLocal(c.phone))}" placeholder="8 705 560 75 87" oninput="formatPhoneField(this)"></div>${contactActions(c.phone,i,false)}<button type="button" class="plusMini" onclick="addExtraPhone()" aria-label="Добавить контакт">+</button></div></div>
 <div id="extraPhones">${extraContacts}</div>
 <label>Адрес</label>${addressBlock}<input id="addressExtra" value="${esc(c.addressExtra||'')}" placeholder="Подъезд, код, этаж, домофон и т. п.">
 <label>Фильтр / модель</label><select id="model">${models.map(x=>`<option ${x===c.model?'selected':''}>${x}</option>`).join('')}</select>
 <label>Картриджи</label><div>${cartridges.map(x=>`<label style="display:block;font-weight:400"><input class="car" type="checkbox" value="${x}" ${(c.cartridges||[]).includes(x)?'checked':''} style="width:auto;margin-right:7px">${x}</label>`).join('')}</div>
 ${i<0?`<div><label>Дата установки</label><input id="install" type="date" value="${c.install||''}"></div>`:''}
 <div class="card serviceSummaryCard" style="margin:12px 0;padding:12px;background:#f7f9fc"><div class="sectionTitle">Обслуживание</div>${i<0?`<div class="serviceSummaryLine"><span>Дата установки</span><b>${c.install?ruDate(c.install):'—'}</b></div>`:''}<div class="serviceSummaryLine"><span>Следующая замена</span><b class="nextServiceDate">${c.replace?ruDate(c.replace):'не указана'}</b></div><button type="button" class="historyMenu" onclick="serviceHistoryList(${i})"><span>История обслуживания</span><span class="arrow">›</span></button>${i>=0&&c.replace?`<button type="button" class="small" onclick="completeCurrentTask(${i})">Выполнено</button>`:''}<div class="serviceManualBlock"><label>Записать выполненную замену вручную</label><div class="grid serviceDateGrid"><div><label>Дата замены</label><input id="serviceDate" type="date" value="${lastService(c)?.date||todayISO()}"></div><div><label>Следующая замена</label><input id="serviceNextDate" type="date" value="${c.replace||''}"></div></div><div id="serviceRows"></div><label>Комментарий к замене</label><textarea id="serviceComment" rows="3" placeholder="Что сделали, замечания"></textarea><button class="secondary small" onclick="addServiceRow()">+ Добавить картридж</button><button class="small" onclick="addServiceRecord(${i})">Записать замену</button></div></div>
 <label>Примечание</label><textarea id="notes" rows="4" placeholder="Дополнительная информация">${esc(c.notes)}</textarea>
 <button type="button" onclick="saveClient(${i})">Сохранить клиента</button>${i>=0?`${isDue(c)?`<button type="button" onclick="completeCurrentTask(${i})" class="secondary">Выполнено</button>`:''}<button type="button" onclick="deleteClient(${i})" class="danger">Удалить</button>`:''}</div>`;
 addServiceRow();
}

function editAddressField(i){
 const c=db.clients[i];
 if(!c)return;
 const box=document.querySelector('.addressRow');
 if(!box)return;
 box.outerHTML=`<input id="address" value="${esc(c.address||'')}" placeholder="Адрес клиента">`;
 document.getElementById('address')?.focus();
}
function chooseMap(i){
 const c=db.clients[i];
 if(!c||!c.address)return;
 const clean=String(c.address).trim();
 if(window.Android&&Android.openMapChooser)Android.openMapChooser(clean);
}
function serviceHistoryList(i){
 setScreen('history');
 const c=db.clients[i];
 if(!c)return;
 const items=serviceHistorySorted(c);
 const historyHtml=items.length?items.slice().reverse().map((h,hi)=>{const realIndex=items.length-1-hi;const num=items.length-hi;return `<button type="button" class="historyItem" onclick="showServiceHistory(${i},${realIndex})"><span><div class="historyNumber">№${num}</div><b>${ruDate(h.date)}</b>${h.nextDate?`<div class="historyNext">Следующая замена: ${ruDate(h.nextDate)}</div>`:''}</span><span class="arrow">›</span></button>`}).join(''):'<div class="empty">Обслуживаний пока не было.</div>';
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">История обслуживания</div><div class="muted">${esc(c.name)||'Без имени'} · №${c.number}</div></div><button type="button" class="secondary" onclick="returnToClientCard(${i})">Назад</button></div><div class="historyInstall"><div class="historyInstallTitle">Дата установки</div><div class="historyInstallDate">${c.install?ruDate(c.install):'—'}</div></div><div class="historyDivider"></div><div class="historySectionTitle">Обслуживание</div>${historyHtml}</div>`;
}

function extraPhoneHtml(p,i,name=''){
 const n=esc(name||'');
 const value=esc(phoneLocal(p));
 return `<div class="contactBlock extraContact"><div class="contactName"><input class="extraContactName" value="${n}" placeholder="Имя контакта"></div><div class="contactPhoneRow"><div class="phoneInputWrap"><input class="extraPhoneInput" inputmode="numeric" maxlength="15" value="${value}" placeholder="8 705 560 75 87" oninput="formatPhoneField(this)"></div>${contactActions(p,i,true)}<button type="button" class="removeMini" onclick="this.parentElement.parentElement.remove()" aria-label="Удалить контакт">−</button></div></div>`;
}
function addExtraPhone(){document.getElementById('extraPhones').insertAdjacentHTML('beforeend',extraPhoneHtml('',Date.now(),''))}
function newClient(){form(-1)}function editClient(i){if(i>=0)form(i)}
function saveClient(i){
 const get = id => document.getElementById(id);
 const extra=[...document.querySelectorAll('.extraContact')].map(box=>({name:(box.querySelector('.extraContactName')?.value||'').trim(),phone:phoneDigits(box.querySelector('.extraPhoneInput')?.value||'')})).filter(x=>x.phone.length===11 || x.name);
 const cs=[...document.querySelectorAll('.car:checked')].map(x=>x.value);
 const history=i<0?[]:(Array.isArray(db.clients[i].serviceHistory)?db.clients[i].serviceHistory:[]);
 const install=i<0 ? (get('install')?.value||'') : (db.clients[i]?.install||'');
 const client={number:i<0 ? db.nextClientNumber : db.clients[i].number,name:get('name').value.trim(),phone:(phoneDigits(get('phone').value).length===11 ? phoneDigits(get('phone').value) : ''),extraPhones:extra,address:(get('address')?.value||db.clients[i]?.address||'').trim(),addressExtra:(get('addressExtra')?.value||db.clients[i]?.addressExtra||'').trim(),model:get('model').value,cartridges:cs,install,replace:(get('serviceNextDate')?.value||db.clients[i]?.replace||''),notes:get('notes').value.trim(),serviceHistory:history};
 delete client.lastReplacementDate;
 delete client.completedDates;
 if(!client.name && !client.phone){alert('Введите имя клиента или номер телефона.');return;}
 if(i<0){db.clients.push(client);db.nextClientNumber++;}else{db.clients[i]=client;}
 try{localStorage.setItem(KEY,JSON.stringify(db));clients();}catch(e){alert('Не удалось сохранить клиента: '+e.message);}
}

function addServiceRow(){document.getElementById('serviceRows').insertAdjacentHTML('beforeend',`<div class="grid serviceRow"><div><label>Картридж</label><select class="servicePart">${cartridges.map(x=>`<option>${x}</option>`).join('')}</select></div><div><label>Производитель</label><select class="serviceBrand">${brands.map(x=>`<option>${x}</option>`).join('')}</select></div></div>`)}
function addServiceRecord(i){
 if(i<0){alert('Сначала сохраните клиента.');return;}
 const rows=[...document.querySelectorAll('.serviceRow')];
 if(!rows.length){alert('Добавьте хотя бы один картридж.');return;}
 const date=document.getElementById('serviceDate').value||todayISO();
 const nextDate=document.getElementById('serviceNextDate').value||'';
 if(db.clients[i].install&&date===db.clients[i].install){alert('Дата установки не является заменой. Укажите фактическую дату обслуживания.');return;}
 const comment=(document.getElementById('serviceComment').value||'').trim();
 const items=rows.map(r=>({part:r.querySelector('.servicePart').value,brand:r.querySelector('.serviceBrand').value}));
 if(!Array.isArray(db.clients[i].serviceHistory))db.clients[i].serviceHistory=[];
 if(db.clients[i].serviceHistory.some(h=>h&&h.completed===true&&h.date===date)){alert('Запись с этой датой уже есть в истории.');return;}
 db.clients[i].serviceHistory.push({date,nextDate,plannedDate:'',items,comment,completed:true});
 db.clients[i].serviceHistory.sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 db.clients[i].replace=nextDate;
 delete db.clients[i].lastReplacementDate;
 delete db.clients[i].completedDates;
 save();
 form(i);
}
function returnToClient(i){
 event?.preventDefault?.();
 event?.stopPropagation?.();
 form(i);
 return false;
}
function addEditServiceRow(part='',brand=''){
 const box=document.getElementById('editServiceRows');
 if(!box)return;
 box.insertAdjacentHTML('beforeend',`<div class="grid editServiceRow"><div><label>Картридж</label><select class="editServicePart">${cartridges.map(v=>`<option ${v===part?'selected':''}>${v}</option>`).join('')}</select></div><div><label>Производитель</label><select class="editServiceBrand">${brands.map(v=>`<option ${v===brand?'selected':''}>${v}</option>`).join('')}</select></div><button type="button" class="removeEditRow" onclick="this.parentElement.remove()">−</button></div>`);
}
function returnToHistoryList(i){
 const idx=Number(i);
 if(Number.isInteger(idx) && idx>=0 && idx<db.clients.length){
  serviceHistoryList(idx);
 }
 return false;
}
function returnToClientCard(i){
 const idx=Number(i);
 if(Number.isInteger(idx) && idx>=0 && idx<db.clients.length){
  form(idx);
 }
 return false;
}
function showServiceHistory(i,hIndex){
 setScreen('serviceDetail');
 const c=db.clients[i];
 if(!c||!Array.isArray(c.serviceHistory)||!c.serviceHistory[hIndex])return;
 const h=c.serviceHistory[hIndex];
 const items=Array.isArray(h.items)?h.items:[];
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">Обслуживание от ${ruDate(h.date)}</div></div><button type="button" class="secondary" onclick="returnToHistoryList(${i})">Назад</button></div>
 <label>Дата замены</label><input id="editServiceDate" type="date" value="${h.date||''}">
 <label>Дата следующей замены</label><input id="editServiceNextDate" type="date" value="${h.nextDate||''}">
 <div style="margin-top:10px"><div class="sectionTitle">Картриджи</div><div id="editServiceRows"></div></div>
 <label>Комментарий</label><textarea id="editServiceComment" rows="4" placeholder="Что сделали, замечания">${esc(h.comment||'')}</textarea>
 <button type="button" class="secondary small" onclick="addEditServiceRow()">+ Добавить картридж</button>
 <button type="button" onclick="saveServiceHistory(${i},${hIndex})">Сохранить изменения</button>
 <button type="button" class="secondary" onclick="returnToHistoryList(${i})">Назад</button></div>`;
 items.forEach(x=>addEditServiceRow(x.part||'',x.brand||''));
 if(!items.length)addEditServiceRow();
}
function saveServiceHistory(i,hIndex){
 const c=db.clients[i],h=c&&c.serviceHistory&&c.serviceHistory[hIndex];
 if(!h)return;
 const date=document.getElementById('editServiceDate').value||h.date;
 const nextDate=document.getElementById('editServiceNextDate').value||'';
 const rows=[...document.querySelectorAll('.editServiceRow')];
 h.date=date;h.nextDate=nextDate;h.items=rows.map(r=>({part:r.querySelector('.editServicePart').value,brand:r.querySelector('.editServiceBrand').value}));
 h.comment=(document.getElementById('editServiceComment').value||'').trim();
 h.completed=true;
 c.serviceHistory.sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 const latest=lastService(c);
 if(latest&&latest.date===h.date)c.replace=nextDate;
 delete c.lastReplacementDate;
 delete c.completedDates;
 save();
 form(i);
}
function deleteClient(i){if(confirm('Удалить клиента №'+db.clients[i].number+'?')){db.clients.splice(i,1);save();clients()}}
function toIntlPhone(phone){const p=phoneDigits(phone);return p.length===11&&p.startsWith('8')?'7'+p.slice(1):p;}
function callPhoneValue(phone){const dial=toIntlPhone(phone);if(!dial)return;if(window.Android&&Android.call){Android.call(dial);}else{location.href='tel:'+dial;}}
function waPhoneValue(phone){const waNumber=toIntlPhone(phone);if(!waNumber)return;if(window.Android)Android.whatsapp(waNumber);else{location.href='https://wa.me/'+waNumber;}}
function callExtraContact(index){const boxes=[...document.querySelectorAll('.extraContact')];const box=boxes[index];if(box)callPhoneValue(box.querySelector('.extraPhoneInput')?.value||'');}
function waExtraContact(index){const boxes=[...document.querySelectorAll('.extraContact')];const box=boxes[index];if(box)waPhoneValue(box.querySelector('.extraPhoneInput')?.value||'');}
function calendar(){
 setScreen('calendar');
 const y=month.getFullYear(),m=month.getMonth(),first=new Date(y,m,1),days=new Date(y,m+1,0).getDate(),offset=(first.getDay()+6)%7;
 let h=`<div class="calendarCard"><div class="row" style="margin-bottom:8px"><div class="sectionTitle">Выберите дату</div><button type="button" class="secondary" onclick="home()">Назад</button></div><div class="calhead row"><button onclick="month.setMonth(month.getMonth()-1);calendar()">‹</button><b>${month.toLocaleDateString('ru-RU',{month:'long',year:'numeric'})}</b><button onclick="month.setMonth(month.getMonth()+1);calendar()">›</button></div><div class="week">${['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(x=>`<div>${x}</div>`).join('')}</div><div class="calendar">`;
 for(let i=0;i<offset;i++)h+='<div></div>';
 for(let d=1;d<=days;d++){let ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,arr=db.clients.filter(c=>c.replace===ds&&!isPlannedCompleted(c,ds)),today=new Date(),isToday=today.getFullYear()===y&&today.getMonth()===m&&today.getDate()===d;h+=`<div class="day ${arr.length?'has':''} ${isToday?'today':''}" onclick="showDate('${ds}')"><span class="dayNum">${d}</span>${arr.length?`<span class=count>${arr.length}</span>`:''}</div>`}
 h+='</div></div>';app.innerHTML=h;
}
function showDate(ds){
 setScreen('date');const arr=db.clients.filter(c=>c.replace===ds);app.innerHTML=`<div class="card"><div class="row"><div class="sectionTitle">Заявки на ${ruDate(ds)}</div><button type="button" class="secondary" onclick="home()">Назад</button></div>${arr.length?arr.map(c=>`<div class="list"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">📞 ${esc(c.phone)} · 🏠 ${esc(c.address)||'—'}${c.addressExtra?` · ${esc(c.addressExtra)}`:''}</div><div class="muted">Установка: ${c.install?ruDate(c.install):'—'} · Следующая замена: ${c.replace?ruDate(c.replace):'—'}</div></div></div>`).join(''):'<div class="empty">На эту дату замен нет.</div>'}</div>`}
function backup(){
 setScreen('backup');app.innerHTML=`<div class="card"><div class="row"><div class="sectionTitle">Сохранение данных</div><button type="button" class="secondary" onclick="home()">Назад</button></div><p class="muted">Сохраняются все данные приложения одним файлом: клиенты, адреса и дополнения к адресу, фильтры, картриджи, история обслуживания, доходы, расходы, счета и операции.</p><button onclick="Android.backup(JSON.stringify({version:2,filters:db,finance:financeDb}))">Сохранить данные</button><button class="secondary" onclick="Android.restore()">Восстановить данные</button></div>`}
function restoreBackup(s){try{const x=JSON.parse(s);
 if(x&&x.version===2&&x.filters&&Array.isArray(x.filters.clients)){db=x.filters;financeDb=(x.finance&&typeof x.finance==='object')?x.finance:financeDb;}
 else if(x&&Array.isArray(x.clients)){db=x;financeDb=db.finance||financeDb;} else throw 0;
 db.clients.forEach(c=>{delete c.mineralizer;delete c.postfilter;delete c.pp100;c.extraPhones=(Array.isArray(c.extraPhones)?c.extraPhones:[]).map(p=>typeof p==='string'?{name:'',phone:p}:{name:String(p?.name||''),phone:String(p?.phone||'')}).filter(p=>p.phone||p.name);c.addressExtra=String(c.addressExtra||'');});
 normalizeServiceHistoryData();
 if(!Number.isInteger(db.nextClientNumber))db.nextClientNumber=db.clients.reduce((m,c)=>Math.max(m,Number(c.number)||0),0)+1;
 if(!financeDb||!Array.isArray(financeDb.incomeSources)||!Array.isArray(financeDb.accounts)||!Array.isArray(financeDb.expenses)||!Array.isArray(financeDb.transactions))financeDb={incomeSources:[],accounts:[],expenses:[],transactions:[]};
 save();financeSave();filterHome();alert('Данные восстановлены')}catch(e){alert('Не удалось восстановить данные')}}
let currentScreen='hub';
let androidBackStack=[];
let restoringAndroidBack=false;
function setScreen(name){
 if(name===currentScreen)return;
 if(!restoringAndroidBack){
  const header=document.querySelector('header');
  const counters=document.getElementById('homeCounters');
  const fab=document.querySelector('.fab');
  androidBackStack.push({screen:currentScreen,html:app.innerHTML,headerDisplay:header?header.style.display:'',countersDisplay:counters?counters.style.display:'',countersClass:counters?counters.className:'',fabDisplay:fab?fab.style.display:''});
 }
 currentScreen=name;
}
function restoreAndroidBackSnapshot(snap){
 restoringAndroidBack=true;currentScreen=snap.screen;app.innerHTML=snap.html;
 const header=document.querySelector('header'),counters=document.getElementById('homeCounters'),fab=document.querySelector('.fab');
 if(header)header.style.display=snap.headerDisplay||'';
 if(counters){counters.style.display=snap.countersDisplay||'';counters.className=snap.countersClass||counters.className;}
 if(fab)fab.style.display=snap.fabDisplay||'';
 restoringAndroidBack=false;
}
function handleAndroidBack(){
 const drawer=document.getElementById('financeDrawerBackdrop');
 if(drawer?.classList.contains('open')){financeCloseMenu();return 'handled';}
 if(document.getElementById('financeCalcBack')){financeCloseCalculator();return 'handled';}
 if(document.getElementById('financeModalBack')){financeCloseModal();return 'handled';}
 if(androidBackStack.length){const snap=androidBackStack.pop();restoreAndroidBackSnapshot(snap);if(snap.screen==='hub'){setShell('hub');androidBackStack=[];}return 'handled';}
 return 'exit';
}
function setShell(mode){const header=document.querySelector('header'),counters=document.getElementById('homeCounters'),fab=document.querySelector('.fab');const hub=mode==='hub',finance=mode==='income';if(header)header.style.display=(hub||finance)?'none':'';if(counters)counters.style.display=(hub||finance)?'none':'';if(fab)fab.style.display=(hub||finance)?'none':'';}
function mainHome(){androidBackStack=[];restoringAndroidBack=true;currentScreen='hub';restoringAndroidBack=false;closeMenu();setShell('hub');app.innerHTML=`<div class="mainHub"><div class="hubTitle">Мои дела</div><div class="hubSub">Выберите нужный раздел</div><div class="hubGrid"><button type="button" class="hubTile filter" onclick="openFilters()"><span class="hubIcon"><svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#1565c0" d="M24 4C17 14 10 21 10 29a14 14 0 0 0 28 0C38 21 31 14 24 4Z"/><path fill="#fff" d="M17 28h14v3H17z"/></svg></span><span class="hubName">Мои фильтры</span><span class="hubHint">Клиенты · замены · заявки</span></button><button type="button" class="hubTile income" onclick="financeHome()"><span class="hubIcon"><svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#16834f" d="M8 12h28a4 4 0 0 1 4 4v20a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4V16a4 4 0 0 1 4-4Z"/><path fill="#fff" d="M32 22h8v10h-8a5 5 0 0 1 0-10Zm0 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/><path fill="#16834f" d="M9 7h24v5H9z"/></svg></span><span class="hubName">Доходы</span><span class="hubHint">Финансы · аналитика</span></button></div></div>`;}
function openFilters(){setShell('filters');filterHome();}
const FIN_KEY='moifiltry_finance_v2';
let financeDb=db.finance||JSON.parse(localStorage.getItem(FIN_KEY)||'null');
if(!financeDb||!Array.isArray(financeDb.incomeSources)||!Array.isArray(financeDb.accounts)||!Array.isArray(financeDb.expenses)||!Array.isArray(financeDb.transactions)) financeDb={incomeSources:[],accounts:[],expenses:[],transactions:[]};
function financeSave(){db.finance=financeDb;save();localStorage.setItem(FIN_KEY,JSON.stringify(financeDb));}
function financeMoney(n){return Number(n||0).toLocaleString('ru-RU',{maximumFractionDigits:2})+' ₸';}
function financeMonth(){return todayISO().slice(0,7);}
let financeSelectedDate=todayISO();
function financeSum(list,kind,month){return list.filter(t=>t.kind===kind&&(!month||String(t.date||'').slice(0,7)===month)).reduce((a,t)=>a+Number(t.amount||0),0);}
function financeAccountBalance(id){let b=Number(financeDb.accounts.find(a=>a.id===id)?.balance||0);financeDb.transactions.forEach(t=>{if(t.kind==='income'&&t.accountId===id)b+=Number(t.amount||0);if(t.kind==='expense'&&t.accountId===id)b-=Number(t.amount||0);if(t.kind==='transfer'&&t.fromId===id)b-=Number(t.amount||0);if(t.kind==='transfer'&&t.toId===id)b+=Number(t.amount||0);});return b;}
function financeDefaultAccountId(){return financeDb.accounts.find(a=>String(a.name).toLowerCase().includes('кэш')||String(a.name).toLowerCase().includes('налич'))?.id||financeDb.accounts[0]?.id||'';}
function financeInit(){
 const old=JSON.parse(localStorage.getItem('moifiltry_income_v1')||'null');
 if(!financeDb.accounts.length) financeDb.accounts=[{id:'acc_default',name:'Кэш',icon:'₸',balance:0}];
 if(!financeDb.incomeSources.length) financeDb.incomeSources=[{id:'inc_default',name:'Технодом',icon:'▣'}];
 if(!financeDb.expenses.length) financeDb.expenses=[{id:'exp_default',name:'Прочее',icon:'•',color:'green'}];
 if(old&&Array.isArray(old.sources)&&old.sources.length&&!financeDb.transactions.length){
  financeDb.incomeSources=old.sources.map((s,i)=>({id:'inc'+Date.now()+i,name:String(s.name||'Доход'),icon:'▣'}));
  old.sources.forEach((s,i)=>(s.entries||[]).forEach(e=>financeDb.transactions.push({id:'t'+Date.now()+Math.random(),kind:'income',sourceId:financeDb.incomeSources[i].id,accountId:financeDefaultAccountId(),amount:Number(e.amount||0),date:e.date||todayISO(),note:''})));
 }
 financeSave();
}
financeInit();
financeSelectedDate=todayISO();
function financeEscName(x){return esc(String(x||''));}
function financeCoinIcon(type,icon){const map={income:'▣',account:'₸',expense:'•'};return `<span style="font-size:27px;font-weight:700;line-height:1">${esc(icon||map[type]||'•')}</span>`;}
function financeCoin(type,item,amount,extra){
 const cls=type==='income'?'incomeCoin':type==='account'?'accountCoin':(item.color==='orange'?'expenseCoin orange':'expenseCoin');
 const fn=type==='income'?`financeSourceDetail('${item.id}')`:type==='account'?`financeAccountDetail('${item.id}')`:`financeExpenseDetail('${item.id}')`;
 const draggable=type==='income'?'data-drag="income"':type==='account'?'data-drag="account"':''; const drop=type==='account'?'data-drop-type="account"':type==='expense'?'data-drop-type="expense"':'';
 return `<div class="coinWrap"><div class="coinLabel" title="${financeEscName(item.name)}">${financeEscName(item.name)}</div><button type="button" class="coin ${cls}" ${draggable} data-id="${esc(item.id)}" ${drop} onclick="${fn}">${financeCoinIcon(type,item.icon)}</button><div class="coinAmount">${amount?financeMoney(amount):'—'}</div>${extra||''}</div>`;
}
function financeAddCoin(type,label){return `<div class="coinWrap"><div class="coinLabel">${label||''}</div><button type="button" class="coin addCoin" onclick="event.preventDefault();event.stopPropagation();financeAdd('${type}')"><span class="plus">+</span></button><div class="coinAmount">Добавить</div></div>`;}
function financeMenuToggle(){const m=document.getElementById('financeDrawerBackdrop');if(m)m.classList.toggle('open');}
function financeCloseMenu(){document.getElementById('financeDrawerBackdrop')?.classList.remove('open');}
document.addEventListener('click',function(e){const m=document.getElementById('financeDrawerBackdrop');const d=m?.querySelector('.financeDrawer');const b=document.querySelector('.financeMenuBtn');if(m?.classList.contains('open')&&!d?.contains(e.target)&&!b?.contains(e.target))m.classList.remove('open');});
function financeSetDate(ds){financeSelectedDate=ds||todayISO();financeHome();}
function financeHeader(){return `<div class="financeHeader"><div class="financeHeaderRow"><button type="button" class="financeMenuBtn" onclick="financeMenuToggle()" aria-label="Меню финансов">☰</button></div><div class="financeDrawerBackdrop" id="financeDrawerBackdrop" onclick="if(event.target===this)financeCloseMenu()"><aside class="financeDrawer" role="dialog" aria-label="Разделы финансов"><div class="financeDrawerHead"><div class="financeDrawerTitle"></div><button type="button" class="financeDrawerClose" onclick="financeCloseMenu()" aria-label="Закрыть">×</button></div><button type="button" onclick="financeOverview();financeCloseMenu()"><span class="financeDrawerIcon">📊</span>Общие данные</button><button type="button" onclick="financeStatistics();financeCloseMenu()"><span class="financeDrawerIcon">◉</span>Статистика</button><button type="button" onclick="financeHistory();financeCloseMenu()"><span class="financeDrawerIcon">🧾</span>История</button><div style="height:8px"></div><button type="button" onclick="backup();financeCloseMenu()"><span class="financeDrawerIcon">💾</span>Сохранить базу данных</button><button type="button" onclick="Android.restore();financeCloseMenu()"><span class="financeDrawerIcon">↥</span>Восстановить базу данных</button></aside></div></div>`;}
function financeHome(){
 setScreen('income');setShell('income');
 const month=String(financeSelectedDate||todayISO()).slice(0,7);
 const incomes=financeDb.transactions.filter(t=>t.kind==='income'&&String(t.date).slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);
 const expenses=financeDb.transactions.filter(t=>t.kind==='expense'&&String(t.date).slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);
 const balance=financeDb.accounts.reduce((a,x)=>a+financeAccountBalance(x.id),0);
 const incomeCoins=financeDb.incomeSources.map(s=>{const sum=financeDb.transactions.filter(t=>t.kind==='income'&&t.sourceId===s.id&&String(t.date).slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);return financeCoin('income',s,sum)}).join('')+financeAddCoin('income','');
 const accountCoins=financeDb.accounts.map(a=>financeCoin('account',a,financeAccountBalance(a.id))).join('')+financeAddCoin('account','');
 const expenseCoins=financeDb.expenses.map(e=>{const sum=financeDb.transactions.filter(t=>t.kind==='expense'&&t.expenseId===e.id&&String(t.date).slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);return financeCoin('expense',e,sum)}).join('')+financeAddCoin('expense','');
 app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeSummary"><div class="financeTop"><div class="financeStat balance">Баланс<b>${financeMoney(balance)}</b></div><div class="financeStat">Расходы<b>${financeMoney(expenses)}</b></div><div class="financeStat">Доходы<b>${financeMoney(incomes)}</b></div></div></div><div class="financeSection"><div class="financeSectionTitle">Доходы</div><div class="financeRow">${incomeCoins}</div></div><div class="financeSection"><div class="financeSectionTitle">Кошельки / счета</div><div class="financeRow">${accountCoins}</div></div><div class="financeSection expenseSection"><div class="financeSectionTitle">Расходы</div><div class="financeRow">${expenseCoins}</div></div></div>`;
 financeBindDrag();
}
function financeAdd(type){
 if(type==='income'){financeAddIncomeSource();return;}
 if(type==='account'){financeAddAccount();return;}
 if(type==='expense'){financeAddExpense();return;}
 financeAddTransfer();
}
function financeOpenAddModal(type){
 const title=type==='income'?'Добавить источник дохода':type==='account'?'Добавить счёт':'Добавить категорию расхода';
 const second=type==='account'?'<label>Начальный баланс, ₸</label><input id="faBalance" inputmode="decimal" placeholder="">':'';
 document.body.insertAdjacentHTML('beforeend',`<div class="financeModalBack" id="financeAddBack" onclick="if(event.target.id==='financeAddBack')financeCloseAddModal()"><div class="financeModal"><h3>${title}</h3><label>${type==='income'?'Источник дохода':type==='account'?'Название счёта':'Категория расхода'}</label><input id="faName" autocomplete="off" placeholder="">${second}<div class="modalButtons"><button class="secondary" onclick="financeCloseAddModal()">Отмена</button><button onclick="financeSaveAddModal('${type}')">Готово</button></div></div></div>`);
 setTimeout(()=>document.getElementById('faName')?.focus(),50);
}
function financeCloseAddModal(){document.getElementById('financeAddBack')?.remove();}
function financeSaveAddModal(type){
 const name=(document.getElementById('faName')?.value||'').trim();
 if(!name){document.getElementById('faName')?.focus();return;}
 if(type==='income') financeDb.incomeSources.push({id:'inc'+Date.now()+Math.random(),name,icon:'▣'});
 else if(type==='expense') financeDb.expenses.push({id:'exp'+Date.now()+Math.random(),name,icon:'•',color:financeDb.expenses.length%3===0?'green':'orange'});
 else {
  const raw=document.getElementById('faBalance')?.value||'';
  const b=raw.trim()===''?0:Number(String(raw).replace(/[^0-9.,-]/g,'').replace(',','.'));
  if(!Number.isFinite(b))return;
  financeDb.accounts.push({id:'acc'+Date.now()+Math.random(),name,icon:'₸',balance:b});
 }
 financeSave();financeCloseAddModal();financeHome();
}
function financeAddIncomeSource(){financeOpenAddModal('income');}
function financeAddAccount(){financeOpenAddModal('account');}
function financeAddExpense(){financeOpenAddModal('expense');}
function financeOpenTransactionModal(kind,pre){pre=pre||{};if(!pre.accountId&&kind==='income')pre.accountId=financeDefaultAccountId();
 const title=kind==='income'?'Доход':kind==='expense'?'Расход':'Перевод';
 let fields='';
 if(kind==='income')fields=`<label>Источник дохода</label><select id="fmSource">${financeDb.incomeSources.map(x=>`<option value="${x.id}" ${x.id===pre?.sourceId?'selected':''}>${financeEscName(x.name)}</option>`).join('')}</select><label>Счёт</label><select id="fmAccount">${financeDb.accounts.map(x=>`<option value="${x.id}" ${x.id===pre?.accountId?'selected':''}>${financeEscName(x.name)}</option>`).join('')}</select>`;
 if(kind==='expense')fields=`<label>Счёт</label><select id="fmAccount">${financeDb.accounts.map(x=>`<option value="${x.id}" ${x.id===pre?.accountId?'selected':''}>${financeEscName(x.name)}</option>`).join('')}</select><label>Категория расхода</label><select id="fmExpense">${financeDb.expenses.map(x=>`<option value="${x.id}" ${x.id===pre?.expenseId?'selected':''}>${financeEscName(x.name)}</option>`).join('')}</select>`;
 if(kind==='transfer')fields=`<label>Откуда</label><select id="fmFrom">${financeDb.accounts.map(x=>`<option value="${x.id}">${financeEscName(x.name)}</option>`).join('')}</select><label>Куда</label><select id="fmTo">${financeDb.accounts.map(x=>`<option value="${x.id}">${financeEscName(x.name)}</option>`).join('')}</select>`;
 document.body.insertAdjacentHTML('beforeend',`<div class="financeModalBack" id="financeModalBack" onclick="if(event.target.id==='financeModalBack')financeCloseModal()"><div class="financeModal"><h3>${title}</h3>${fields}<label>Сумма, ₸</label><input id="fmAmount" inputmode="decimal" placeholder="1000"><label>Дата</label><input id="fmDate" type="date" value="${pre.date||financeSelectedDate||todayISO()}"><label>Комментарий</label><input id="fmNote" placeholder="Необязательно"><div class="modalButtons"><button class="secondary" onclick="financeCloseModal()">Отмена</button><button onclick="financeSaveModal('${kind}')">Готово</button></div></div></div>`);
}
function financeCloseModal(){document.getElementById('financeModalBack')?.remove();}
function financeSaveModal(kind){const amount=Number(String(document.getElementById('fmAmount')?.value||'').replace(/[^0-9.,-]/g,'').replace(',','.'));if(!Number.isFinite(amount)||amount<=0){alert('Введите корректную сумму.');return;}const date=document.getElementById('fmDate')?.value||todayISO();const note=document.getElementById('fmNote')?.value||'';const t={id:'t'+Date.now()+Math.random(),kind,amount,date,note};if(kind==='income'){t.sourceId=document.getElementById('fmSource').value;t.accountId=document.getElementById('fmAccount').value;}else if(kind==='expense'){t.accountId=document.getElementById('fmAccount').value;t.expenseId=document.getElementById('fmExpense').value;}else{t.fromId=document.getElementById('fmFrom').value;t.toId=document.getElementById('fmTo').value;if(t.fromId===t.toId){alert('Выберите разные счета.');return;}}financeDb.transactions.push(t);financeSave();financeCloseModal();financeHome();}
function financeRowsForDate(rows){const ds=financeSelectedDate||todayISO();return rows.filter(t=>String(t.date||'')===ds);}
function financeAddTransfer(){if(financeDb.accounts.length<2){alert('Сначала создайте минимум два счёта.');return;}financeOpenTransactionModal('transfer');}
let financeDrag=null;
let financeDragSensorBound=false;
let financeTouchActive=false;
let financeSuppressClickId='';
let financeSuppressClickUntil=0;
function financeClearDragVisuals(){document.querySelectorAll('.dragTarget').forEach(x=>x.classList.remove('dragTarget'));}
function financeFindDropTarget(x,y,preferredId){
 const targets=[...document.querySelectorAll('[data-drop-type="account"]')];
 if(preferredId){const preferred=targets.find(t=>t.dataset.id===preferredId);if(preferred)return preferred;}
 const nodes=document.elementsFromPoint?document.elementsFromPoint(x,y):[];
 for(const node of nodes){const target=node.closest?.('[data-drop-type="account"]');if(target)return target;}
 let best=null,bestDist=Infinity;
 for(const target of targets){
  const r=target.getBoundingClientRect();
  const pad=30;
  if(x>=r.left-pad&&x<=r.right+pad&&y>=r.top-pad&&y<=r.bottom+pad)return target;
  const cx=(r.left+r.right)/2,cy=(r.top+r.bottom)/2;
  const dist=Math.hypot(x-cx,y-cy);
  if(dist<bestDist){bestDist=dist;best=target;}
 }
 return bestDist<=92?best:null;
}
function financeMakeDragGhost(el,x,y){
 const ghost=el.cloneNode(true);
 ghost.className='financeDragGhost '+[...el.classList].filter(c=>c!=='dragTarget').join(' ');
 ghost.removeAttribute('onclick');
 ghost.removeAttribute('data-drag');
 ghost.removeAttribute('data-drop-type');
 ghost.style.left=x+'px';
 ghost.style.top=y+'px';
 ghost.style.background=getComputedStyle(el).background;
 document.body.appendChild(ghost);
 return ghost;
}
function financeMoveDragGhost(ghost,x,y){if(ghost){ghost.style.left=x+'px';ghost.style.top=y+'px';}}
function financeStartDrag(el,type,id,x,y,input){
 if(financeDrag)return;
 financeDrag={type,id,startX:x,startY:y,lastX:x,lastY:y,moved:false,pointerId:null,el,ghost:null,input,lastTargetId:null};
}
function financeUpdateDrag(x,y){
 const d=financeDrag;if(!d)return;
 d.lastX=x;d.lastY=y;
 const dist=Math.hypot(x-d.startX,y-d.startY);
 if(dist<=7)return;
 d.moved=true;
 if(d.ghost===null)d.ghost=financeMakeDragGhost(d.el,x,y);
 financeMoveDragGhost(d.ghost,x,y);
 financeClearDragVisuals();
 const target=financeFindDropTarget(x,y);
 if(target&&target.dataset.id!==d.id){d.lastTargetId=target.dataset.id;target.classList.add('dragTarget');}
}
function financeFinishDrag(cancelled=false,x,y){
 const d=financeDrag;if(!d)return;
 const px=Number.isFinite(x)?x:d.lastX;
 const py=Number.isFinite(y)?y:d.lastY;
 let target=cancelled?null:financeFindDropTarget(px,py,d.lastTargetId);
 if(target&&target.dataset.id===d.id)target=null;
 if(!target&&!cancelled&&d.lastTargetId)target=financeFindDropTarget(px,py,d.lastTargetId);
 if(d.ghost)d.ghost.remove();
 financeClearDragVisuals();
 financeDrag=null;
 financeTouchActive=false;
 if(cancelled||!d.moved)return;
 financeSuppressClickId=d.id;
 financeSuppressClickUntil=Date.now()+900;
 if(!target)return;
 const dropType=target.dataset.dropType;
 const targetId=target.dataset.id;
 if(d.type==='income'&&dropType==='account')financeOpenCalculator('income',{sourceId:d.id,accountId:targetId});
 else if(d.type==='account'&&dropType==='expense')financeOpenCalculator('expense',{accountId:d.id,expenseId:targetId});
 else if(d.type==='account'&&dropType==='account'&&targetId!==d.id)financeOpenCalculator('transfer',{fromId:d.id,toId:targetId});
}
function financePointerDown(e){
 if(financeTouchActive)return;
 const el=e.target?.closest?.('[data-drag]');
 if(!el||!document.body.contains(el))return;
 if(e.button!==undefined&&e.button!==0)return;
 if(e.pointerId===undefined||e.pointerId===null)return;
 if(financeDrag)return;
 financeStartDrag(el,el.dataset.drag,el.dataset.id,e.clientX,e.clientY,'pointer');
 financeDrag.pointerId=e.pointerId;
}
function financePointerMove(e){
 const d=financeDrag;if(!d||d.input!=='pointer'||e.pointerId!==d.pointerId)return;
 financeUpdateDrag(e.clientX,e.clientY);
 if(d.moved)e.preventDefault();
}
function financePointerUp(e){
 const d=financeDrag;if(!d||d.input!=='pointer'||e.pointerId!==d.pointerId)return;
 financeFinishDrag(false,e.clientX,e.clientY);
}
function financeTouchStart(e){
 const touch=e.touches?.[0];
 const el=e.target?.closest?.('[data-drag]');
 if(!touch||!el||!document.body.contains(el))return;
 if(financeDrag)return;
 financeTouchActive=true;
 financeStartDrag(el,el.dataset.drag,el.dataset.id,touch.clientX,touch.clientY,'touch');
}
function financeTouchMove(e){
 const d=financeDrag;if(!d||d.input!=='touch')return;
 const touch=e.touches?.[0];if(!touch)return;
 financeUpdateDrag(touch.clientX,touch.clientY);
 if(d.moved)e.preventDefault();
}
function financeTouchEnd(e){
 const d=financeDrag;if(!d||d.input!=='touch')return;
 const touch=e.changedTouches?.[0];
 financeFinishDrag(false,touch?.clientX,touch?.clientY);
}
function financeTouchCancel(){
 if(financeDrag?.input==='touch')financeFinishDrag(true);
 financeTouchActive=false;
}
function financeBindDrag(){
 if(financeDragSensorBound)return;
 financeDragSensorBound=true;
 document.addEventListener('pointerdown',financePointerDown,{passive:false,capture:true});
 document.addEventListener('pointermove',financePointerMove,{passive:false,capture:true});
 document.addEventListener('pointerup',financePointerUp,{passive:false,capture:true});
 document.addEventListener('pointercancel',e=>{if(financeDrag?.input==='pointer')financeFinishDrag(true);},{passive:false,capture:true});
 document.addEventListener('touchstart',financeTouchStart,{passive:false,capture:true});
 document.addEventListener('touchmove',financeTouchMove,{passive:false,capture:true});
 document.addEventListener('touchend',financeTouchEnd,{passive:false,capture:true});
 document.addEventListener('touchcancel',financeTouchCancel,{passive:false,capture:true});
 document.addEventListener('click',function(e){
  if(!financeSuppressClickId||Date.now()>financeSuppressClickUntil){financeSuppressClickId='';return;}
  const el=e.target?.closest?.('[data-drag]');
  if(el&&el.dataset.id===financeSuppressClickId){e.preventDefault();e.stopPropagation();}
  financeSuppressClickId='';
 },true);
}

function financeOpenCalculator(kind,meta){financeCalc={kind,meta:meta||{},value:'0'};const route=financeEscName(financeCalcName(kind,financeCalc.meta));document.body.insertAdjacentHTML('beforeend',`<div class="financeCalcBack" id="financeCalcBack" onclick="if(event.target.id==='financeCalcBack')financeCloseCalculator()"><div class="financeCalc"><div class="financeCalcHead"><button type="button" class="financeCalcClose" onclick="financeCloseCalculator()">×</button><div class="financeCalcRoute">${route}</div><div style="width:38px"></div></div><div class="financeCalcDisplay" id="financeCalcDisplay">0</div><div class="financeCalcMeta">Введите сумму</div><div class="financeCalcKeys"><button onclick="financeCalcInput('1')">1</button><button onclick="financeCalcInput('2')">2</button><button onclick="financeCalcInput('3')">3</button><button class="calcAction" onclick="financeCalcInput('back')">←</button><button onclick="financeCalcInput('4')">4</button><button onclick="financeCalcInput('5')">5</button><button onclick="financeCalcInput('6')">6</button><button class="calcAction" onclick="financeCalcInput('clear')">C</button><button onclick="financeCalcInput('7')">7</button><button onclick="financeCalcInput('8')">8</button><button onclick="financeCalcInput('9')">9</button><button class="calcAction" onclick="financeCalcInput(',')">,</button><button onclick="financeCalcInput('0')">0</button><button class="calcOk" style="grid-column:span 3" onclick="financeSaveCalculator()">✓ Готово</button></div></div></div>`);}
function financeCloseCalculator(){document.getElementById('financeCalcBack')?.remove();financeCalc={kind:'income',meta:{},value:'0'};}
function financeSaveCalculator(){const amount=Number(financeCalc.value);if(!Number.isFinite(amount)||amount<=0){alert('Введите сумму.');return;}const t={id:'t'+Date.now()+Math.random(),kind:financeCalc.kind,amount,date:todayISO(),note:''};if(financeCalc.kind==='income'){t.sourceId=financeCalc.meta.sourceId;t.accountId=financeCalc.meta.accountId;}else if(financeCalc.kind==='expense'){t.accountId=financeCalc.meta.accountId;t.expenseId=financeCalc.meta.expenseId;}else{t.fromId=financeCalc.meta.fromId;t.toId=financeCalc.meta.toId;}financeDb.transactions.push(t);financeSave();financeCloseCalculator();financeHome();}
function financeDropMarkup(type,item){return ''}
function financeSourceDetail(id){const s=financeDb.incomeSources.find(x=>x.id===id);if(!s)return;setScreen('financeSource');setShell('income');const all=financeDb.transactions.filter(t=>t.kind==='income'&&t.sourceId===id);const rows=financeRowsForDate(all);const total=all.reduce((a,t)=>a+Number(t.amount||0),0);app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeDetail"><div class="financeDetailHead"><div class="financeDetailTitle">${financeEscName(s.name)}</div></div><div class="financeDetailAmount">${financeMoney(total)}</div><button onclick="financeOpenTransactionModal('income',{sourceId:'${id}',accountId:financeDefaultAccountId()})">＋ Записать доход</button><button class="danger small" onclick="financeDeleteSource('${id}')">Удалить</button></div><div class="financeDetail"><div class="sectionTitle">Операции за ${ruDate(financeSelectedDate)}</div><div class="financeList">${rows.length?rows.map(t=>`<div class="financeListRow"><div><div class="name financeIncome">Доход</div><div class="meta">${ruDate(t.date)}${t.note?' · '+financeEscName(t.note):''}</div></div><div class="sum financeIncome">+${financeMoney(t.amount)}</div></div>`).join(''):'<div class="financeEmpty">На выбранную дату операций нет.</div>'}</div></div></div>`;}
function financeAccountDetail(id){const a=financeDb.accounts.find(x=>x.id===id);if(!a)return;setScreen('financeAccount');setShell('income');const all=financeDb.transactions.filter(t=>t.accountId===id||t.fromId===id||t.toId===id);const rows=financeRowsForDate(all);app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeDetail"><div class="financeDetailHead"><div class="financeDetailTitle">${financeEscName(a.name)}</div></div><div class="financeDetailAmount">${financeMoney(financeAccountBalance(id))}</div><button onclick="financeOpenTransactionModal('income',{accountId:'${id}'})">＋ Доход</button><button onclick="financeOpenTransactionModal('expense',{accountId:'${id}'})">− Расход</button></div><div class="financeDetail"><div class="sectionTitle">Операции за ${ruDate(financeSelectedDate)}</div><div class="financeList">${rows.length?rows.map(t=>{const source=t.kind==='income'?financeDb.incomeSources.find(x=>x.id===t.sourceId)?.name:'';const from=t.kind==='transfer'?financeDb.accounts.find(x=>x.id===t.fromId)?.name:'';const to=t.kind==='transfer'?financeDb.accounts.find(x=>x.id===t.toId)?.name:'';let label=t.kind==='income'?(source?(source+' → '+a.name):'Доход'):t.kind==='expense'?'Расход':(from||'Счёт')+' → '+(to||'Счёт');let sign=t.kind==='income'?'+':t.kind==='expense'?'−':(t.toId===id?'+':'−');let cls=t.kind==='income'?'financeIncome':t.kind==='expense'?'financeExpense':'financeTransfer';return `<div class="financeListRow"><div><div class="name ${cls}">${financeEscName(label)}</div><div class="meta">${ruDate(t.date)}${t.note?' · '+financeEscName(t.note):''}</div></div><div class="sum ${cls}">${sign}${financeMoney(t.amount)}</div></div>`}).join(''):'<div class="financeEmpty">На выбранную дату операций нет.</div>'}</div></div></div>`;}
function financeExpenseDetail(id){const e=financeDb.expenses.find(x=>x.id===id);if(!e)return;setScreen('financeExpense');const rows=financeDb.transactions.filter(t=>t.kind==='expense'&&t.expenseId===id).slice().reverse();const total=rows.reduce((a,t)=>a+Number(t.amount||0),0);app.innerHTML=`<div class="financeDetail"><div class="financeDetailHead"><div class="financeDetailTitle">${financeEscName(e.name)}</div></div><div class="financeDetailAmount">${financeMoney(total)}</div><button onclick="financeOpenTransactionModal('expense',{expenseId:'${id}'})">− Записать расход</button><button class="danger small" onclick="financeDeleteExpense('${id}')">Удалить</button></div><div class="financeDetail"><div class="sectionTitle">Операции</div><div class="financeList">${rows.length?rows.map(t=>`<div class="financeListRow"><div><div class="name financeExpense">Расход</div><div class="meta">${ruDate(t.date)}${t.note?' · '+financeEscName(t.note):''}</div></div><div class="sum financeExpense">−${financeMoney(t.amount)}</div></div>`).join(''):'<div class="financeEmpty">Пока нет операций.</div>'}</div></div>`;}
function financeDeleteSource(id){if(!confirm('Удалить источник дохода?'))return;financeDb.incomeSources=financeDb.incomeSources.filter(x=>x.id!==id);financeDb.transactions=financeDb.transactions.filter(t=>t.sourceId!==id);financeSave();financeHome();}
function financeDeleteExpense(id){if(!confirm('Удалить категорию расхода?'))return;financeDb.expenses=financeDb.expenses.filter(x=>x.id!==id);financeDb.transactions=financeDb.transactions.filter(t=>t.expenseId!==id);financeSave();financeHome();}
function financeHistory(){setScreen('financeHistory');setShell('income');const rows=financeDb.transactions.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeDetail"><div class="financeDetailHead"><div class="financeDetailTitle">История операций</div></div><div class="financeList">${rows.length?rows.slice(0,200).map(t=>{const s=financeDb.incomeSources.find(x=>x.id===t.sourceId)?.name;const e=financeDb.expenses.find(x=>x.id===t.expenseId)?.name;const a=financeDb.accounts.find(x=>x.id===t.accountId)?.name;const from=financeDb.accounts.find(x=>x.id===t.fromId)?.name;const to=financeDb.accounts.find(x=>x.id===t.toId)?.name;const label=t.kind==='income'?(s?(s+(a?' → '+a:'')):'Доход'):t.kind==='expense'?e||'Расход':(from||'Счёт')+' → '+(to||'Счёт');const sign=t.kind==='income'?'+':t.kind==='expense'?'−':'⇄';const cls=t.kind==='income'?'financeIncome':t.kind==='expense'?'financeExpense':'financeTransfer';return `<div class="financeListRow"><div><div class="name ${cls}">${financeEscName(label)}</div><div class="meta">${ruDate(t.date)}${a?' · '+financeEscName(a):''}${t.note?' · '+financeEscName(t.note):''}</div></div><div class="sum ${cls}">${sign}${financeMoney(t.amount)}</div></div>`}).join(''):'<div class="financeEmpty">Операций пока нет.</div>'}</div></div></div>`;}
function financeOverview(){
 setScreen('financeOverview');setShell('income');
 const tx=financeDb.transactions;
 const month=financeMonth();
 const totalIncome=tx.filter(t=>t.kind==='income'&&String(t.date||'').slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);
 const totalExpense=tx.filter(t=>t.kind==='expense'&&String(t.date||'').slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);
 const sourceTotals=[];financeDb.incomeSources.forEach((s,i)=>{const value=tx.filter(t=>t.kind==='income'&&t.sourceId===s.id&&String(t.date||'').slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);if(value>0)sourceTotals.push({name:s.name,value,color:['#e84d4d','#d99a27','#e2c044','#8b6bd6','#4aa3df','#55ad72'][i%6]});});
 const fallback=sourceTotals.length?sourceTotals:[{name:'Доход',value:totalIncome,color:'#e84d4d'}];
 const sum=fallback.reduce((a,x)=>a+x.value,0);let acc=0;const stops=fallback.map(x=>{const a=acc;acc+=x.value/sum*360;return `${x.color} ${a}deg ${acc}deg`;}).join(',');
 const legend=fallback.map(x=>{const pct=sum?Math.round(x.value/sum*100):0;return `<div class="financeRingLegendRow"><span><i class="financeRingDot" style="background:${x.color}"></i>${financeEscName(x.name)}</span><b>${pct}%</b><span>${financeMoney(x.value)}</span></div>`}).join('');
 const monthName=new Date().toLocaleDateString('ru-RU',{month:'long',year:'numeric'});
 app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeAnalytics"><div class="financeAnalyticsCard"><div class="financeAnalyticsTitle">Общие данные</div><div class="financeOverviewRing" style="background:conic-gradient(${stops})"><div class="financeOverviewRingInner"><div class="financeOverviewMonth">${monthName}</div><div class="financeOverviewTotal">${financeMoney(totalIncome)}</div></div></div><div class="financeRingLegend">${legend}</div></div><div class="financeAnalyticsCard"><div class="financeAnalyticsTitle">Итоги</div><div class="financeAnalyticsRow"><span>Всего доходов</span><b class="financeIncome">${financeMoney(totalIncome)}</b></div><div class="financeAnalyticsRow"><span>Всего расходов</span><b class="financeExpense">${financeMoney(totalExpense)}</b></div><div class="financeAnalyticsRow"><span>Разница</span><b>${financeMoney(totalIncome-totalExpense)}</b></div></div></div></div>`;
}
function financeRingMarkup(name,value,total){const pct=total>0?Math.round(value/total*100):0;const deg=Math.max(0,Math.min(360,pct*3.6));return `<div class="financeRingRow"><div class="financeRing" style="--ring:${deg}deg"><div class="financeRingInner">${pct}%</div></div><div class="financeRingText"><b>${financeEscName(name)}</b><span>${financeMoney(value)}</span></div></div>`;}
function financeStatistics(){
 setScreen('financeStatistics');setShell('income');
 const tx=financeDb.transactions,totalIncome=tx.filter(t=>t.kind==='income').reduce((a,t)=>a+Number(t.amount||0),0),totalExpense=tx.filter(t=>t.kind==='expense').reduce((a,t)=>a+Number(t.amount||0),0);
 const sourceTotals=financeDb.incomeSources.map(s=>({name:s.name,value:tx.filter(t=>t.kind==='income'&&t.sourceId===s.id).reduce((a,t)=>a+Number(t.amount||0),0)})).filter(x=>x.value>0);
 const sourceRows=sourceTotals.map(x=>`<div class="financeAnalyticsRow"><span>${financeEscName(x.name)}</span><b>${totalIncome?Math.round(x.value/totalIncome*100):0}% · ${financeMoney(x.value)}</b></div>`).join('');
 const accountRows=financeDb.accounts.map(a=>`<div class="financeAnalyticsRow"><span>${financeEscName(a.name)}</span><b>${financeMoney(financeAccountBalance(a.id))}</b></div>`).join('');
 app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeAnalytics"><div class="financeAnalyticsCard"><div class="financeAnalyticsTitle">Статистика</div><div class="financeAnalyticsRow"><span>Всего доходов</span><b class="financeIncome">${financeMoney(totalIncome)}</b></div><div class="financeAnalyticsRow"><span>Всего расходов</span><b class="financeExpense">${financeMoney(totalExpense)}</b></div><div class="financeAnalyticsRow"><span>Разница</span><b>${financeMoney(totalIncome-totalExpense)}</b></div></div><div class="financeAnalyticsCard"><div class="financeAnalyticsTitle">Источники дохода</div>${sourceRows||'<div class="financeEmpty">Данных пока нет.</div>'}</div><div class="financeAnalyticsCard"><div class="financeAnalyticsTitle">Кошельки / счета</div>${accountRows||'<div class="financeEmpty">Счетов нет.</div>'}</div></div></div>`;
}

initTopDate();
setInterval(()=>{initTopDate();updateHomeCounters();},60000);
mainHome();
