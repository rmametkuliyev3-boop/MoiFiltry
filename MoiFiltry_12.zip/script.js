
const KEY='moifiltry5';
let db=JSON.parse(localStorage.getItem(KEY)||'null');
if(!db) db={clients:[],nextClientNumber:1};
if(!Array.isArray(db.clients)) db.clients=[];
// 5.1: remove legacy fields that are no longer used in the interface.
db.clients.forEach(c=>{delete c.mineralizer;delete c.postfilter;delete c.pp100;});
if(!Number.isInteger(db.nextClientNumber)||db.nextClientNumber<1) db.nextClientNumber=(db.clients.reduce((m,c)=>Math.max(m,Number(c.number)||0),0)+1);
let month=new Date();month.setDate(1);
let homeSearchOpen=false;
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const save=()=>localStorage.setItem(KEY,JSON.stringify(db));
const models=['Ecosoft с насосом','Ecosoft без насоса','FitAqua с насосом','FitAqua без насоса','Другое'];
const cartridges=['PP5','GAC','CTO','PP1','Пост-фильтр','Минерализатор','RO-мембрана'];
const brands=['Вастерлайн','Ecosoft','FitAqua'];
function hideHomeCounters(){}
function toggleMenu(){document.getElementById('menu').classList.toggle('open')}
function closeMenu(){document.getElementById('menu').classList.remove('open')}
function todayISO(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function ruDate(ds){if(!ds)return '—';const [y,m,d]=ds.split('-');return `${d}.${m}.${y}`}
function initTopDate(){document.getElementById('topDate').textContent='📅 '+ruDate(todayISO());}
function openTopCalendar(){calendar();}
function isOverdue(c){const t=todayISO();return !!(c.replace&&c.replace<t&&!(c.completedDates||[]).includes(c.replace))}
function updateHomeCounters(){
 const box=document.getElementById('homeCounters');
 if(!box)return;
 const t=todayISO();
 const todayCount=db.clients.filter(c=>c.replace===t&&!(c.completedDates||[]).includes(c.replace)).length;
 const overdueCount=db.clients.filter(isOverdue).length;
 document.getElementById('todayCounter').textContent=todayCount;
 document.getElementById('overdueCounter').textContent=overdueCount;
}
function toggleHomeSearch(){
 if(!app.innerHTML.includes('id="homeSearch"')){home();homeSearchOpen=true;home();}
 else {homeSearchOpen=!homeSearchOpen;home();}
}

function clients(){
 const q=(document.getElementById('search')?.value||'').toLowerCase();
 const arr=db.clients.filter(c=>[c.name,c.phone,c.address,c.model,String(c.number)].join(' ').toLowerCase().includes(q));
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">Клиентская база</div><div class="stat">${db.clients.length}</div><div class="muted">Всего клиентов</div></div><div><button type="button" class="secondary" onclick="home()">Назад</button><button onclick="newClient()">+ Новый клиент</button></div></div></div>
 <div class="card"><input id="search" class="search" placeholder="Поиск клиента: имя, телефон, адрес или №" value="${esc(q)}" oninput="clients()"></div>`+
 (arr.length?arr.map(c=>`<div class="card client" onclick="editClientByNumber(${c.number})"><div class="row"><b>№${c.number} — ${esc(c.name)||'Без имени'}</b><span class="muted">${esc(formatPhoneDisplay(c.phone))}</span></div><div>${c.model?`<span class=pill>${esc(c.model)}</span>`:''}${(c.cartridges||[]).map(x=>`<span class=pill>${esc(x)}</span>`).join('')}</div><div class="muted">🏠 ${esc(c.address)||'Адрес не указан'}</div><div class="muted">Установка: ${c.install||'—'} · Следующая замена: ${c.replace||'—'}</div></div>`).join(''):`<div class="card empty">Ничего не найдено.</div>`);
}
function home(){
 const today=todayISO();
 const todayTasks=db.clients.filter(c=>c.replace===today&&!(c.completedDates||[]).includes(c.replace));
 const overdue=db.clients.filter(isOverdue);
 app.innerHTML=`${homeSearchOpen?`<div class="card"><input id="homeSearch" class="search" placeholder="Поиск клиента" oninput="homeSearch()" autofocus></div><div id="homeResults"></div>`:''}${todayTasks.length?`<div class="card"><div class="sectionTitle">Заявки на сегодня</div>${todayTasks.map(c=>`<div class="list"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">Замена: ${ruDate(c.replace)}</div></div></div>`).join('')}</div>`:''}`;
 const counters=document.getElementById('homeCounters');
 if(counters)counters.classList.add('open');
 updateHomeCounters();
}
function homeSearch(){const q=(document.getElementById('homeSearch')?.value||'').toLowerCase();const box=document.getElementById('homeResults');if(!box)return;if(!q){box.innerHTML='';return;}const arr=db.clients.filter(c=>[c.name,c.phone,c.address,c.model,String(c.number)].join(' ').toLowerCase().includes(q));box.innerHTML=arr.length?`<div class="card">${arr.map(c=>`<div class="list" onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)||'Без имени'}</b><div class="muted">${esc(formatPhoneDisplay(c.phone))} · ${esc(c.address)||'Адрес не указан'}</div></div>`).join('')}</div>`:'<div class="card empty">Клиент не найден.</div>'}
function showOverdue(){const arr=db.clients.filter(isOverdue);app.innerHTML=`<div class="card"><div class="row"><div class="sectionTitle">Просроченные</div><button type="button" class="secondary" onclick="home()">Назад</button></div>${arr.length?arr.map(c=>`<div class="list"><div class="row"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">Просрочено с ${ruDate(c.replace)}</div></div><button class="small" onclick="completeTask(${c.number},'${c.replace}')">Выполнено</button></div></div>`).join(''):'<div class="empty">Просроченных заявок нет.</div>'}</div>`}
function completeCurrentTask(i){const c=db.clients[i];if(!c||!isOverdue(c))return;completeTask(c.number,c.replace)}
function completeTask(n,ds){
 const i=getIndexByNumber(n);if(i<0)return;
 const c=db.clients[i];
 if(!Array.isArray(c.completedDates))c.completedDates=[];
 if(c.completedDates.includes(ds))return;
 c.completedDates.push(ds);
 if(!Array.isArray(c.serviceHistory))c.serviceHistory=[];
 const known={};
 c.serviceHistory.forEach(h=>(h.items||[]).forEach(x=>{if(x.part&&x.brand)known[x.part]=x.brand;}));
 const items=(c.cartridges||[]).map(part=>({part,brand:known[part]||'Не указан'}));
 c.serviceHistory.push({date:ds,items,completed:true});
 save();home();
}

function migratePhoneNumbers(){
 db.clients.forEach(c=>{
  if(c.phone) c.phone=phoneDigits(c.phone);
  if(Array.isArray(c.extraPhones)) c.extraPhones=c.extraPhones.map(phoneDigits).filter(x=>x);
 });
}

function getIndexByNumber(n){return db.clients.findIndex(c=>Number(c.number)===Number(n))}
migratePhoneNumbers();
function editClientByNumber(n){editClient(getIndexByNumber(n))}
function phoneDigits(value){
 const raw=String(value||'').replace(/\D/g,'');
 if(raw.startsWith('8') && raw.length>=11) return raw.slice(0,11);
 if(raw.startsWith('7') && raw.length>=11) return '8'+raw.slice(1,11);
 if(raw.startsWith('8')) return raw.slice(0,11);
 return raw.slice(0,11);
}
function phoneLocal(value){
 const d=phoneDigits(value);
 return d.startsWith('8') ? d : '';
}
function formatPhoneField(el){
 let d=phoneDigits(el.value);
 if(d && !d.startsWith('8') && d.length===10) d='8'+d;
 let out=d;
 if(d.length>1) out=d.slice(0,1)+' '+d.slice(1);
 if(d.length>4) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4);
 if(d.length>7) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7);
 if(d.length>9) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7,9)+' '+d.slice(9);
 el.value=out;
}
function formatPhoneDisplay(value){
 const d=phoneDigits(value);
 if(!d) return '';
 let out=d;
 if(d.length>1) out=d.slice(0,1)+' '+d.slice(1);
 if(d.length>4) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4);
 if(d.length>7) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7);
 if(d.length>9) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7,9)+' '+d.slice(9);
 return out;
}
function phoneForWhatsApp(value){
 const d=phoneDigits(value);
 return d.startsWith('8') && d.length===11 ? '7'+d.slice(1) : d.replace(/^\+/, '');
}
function form(i){
 const c=i<0?{number:db.nextClientNumber,name:'',phone:'',extraPhones:[],address:'',model:'Ecosoft с насосом',cartridges:[],install:'',replace:'',notes:'',serviceHistory:[]}:db.clients[i];
 if(!Array.isArray(c.serviceHistory))c.serviceHistory=[];
 const addressBlock=c.address?`<div class="addressRow"><button type="button" class="addressLink" onclick="chooseMap(${i})">🏠 ${esc(c.address)}</button><button type="button" class="secondary small addressEdit" onclick="editAddressField(${i})">Изменить</button></div>`:`<input id="address" value="" placeholder="Адрес клиента">`;
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">${i<0?'Новый клиент':'Карточка клиента'}</div><div class="muted">№${c.number}</div></div><button type="button" class="secondary" onclick="clients()">Назад</button></div>
 <label>Имя клиента</label><input id="name" value="${esc(c.name)}" placeholder="Имя и фамилия">
 <label>Основной телефон</label><div class="phoneRow"><div class="phoneInputWrap"><input id="phone" inputmode="numeric" maxlength="15" value="${esc(phoneLocal(c.phone))}" placeholder="8 705 560 75 87" oninput="formatPhoneField(this)"></div><button class="plusMini" onclick="addExtraPhone()">+</button></div>
 <div id="extraPhones">${(c.extraPhones||[]).map((p,i)=>extraPhoneHtml(p,i)).join('')}</div>
 <label>Адрес</label>${addressBlock}
 <label>Фильтр / модель</label><select id="model">${models.map(x=>`<option ${x===c.model?'selected':''}>${x}</option>`).join('')}</select>
 <label>Картриджи</label><div>${cartridges.map(x=>`<label style="display:block;font-weight:400"><input class="car" type="checkbox" value="${x}" ${(c.cartridges||[]).includes(x)?'checked':''} style="width:auto;margin-right:7px">${x}</label>`).join('')}</div>
 <div><label>Дата установки</label><input id="install" type="date" value="${c.install||''}"></div>
 <div class="card" style="margin:12px 0;padding:12px;background:#f7f9fc"><div class="sectionTitle">История обслуживания</div><button type="button" class="historyMenu" onclick="serviceHistoryList(${i})"><span>История обслуживания</span><span class="arrow">›</span></button><div style="margin-top:10px"><label>Новая замена</label><div class="grid serviceDateGrid"><div><label>Дата замены</label><input id="serviceDate" type="date" value="${todayISO()}"></div><div><label>Дата следующей замены</label><input id="serviceNextDate" type="date" value="${c.replace||''}"></div></div><div id="serviceRows"></div><label>Комментарий к замене</label><textarea id="serviceComment" rows="3" placeholder="Что сделали, замечания"></textarea><button class="secondary small" onclick="addServiceRow()">+ Добавить картридж</button><button class="small" onclick="addServiceRecord(${i})">Записать замену</button></div></div>
 <label>Примечание</label><textarea id="notes" rows="4" placeholder="Дополнительная информация">${esc(c.notes)}</textarea>
 <button onclick="saveClient(${i})">Сохранить клиента</button>${i>=0?`${isOverdue(c)?`<button onclick="completeCurrentTask(${i})" class="secondary">Выполнено</button>`:''}<button onclick="callClient(${i})" class="secondary">Позвонить</button><button onclick="wa(${i})" class="secondary">WhatsApp</button><button onclick="deleteClient(${i})" class="danger">Удалить</button>`:''}</div>`;
 addServiceRow();
}

function editAddressField(i){
 const c=db.clients[i];
 if(!c)return;
 const box=document.querySelector('.addressRow');
 if(!box)return;
 box.outerHTML=`<input id="address" value="${esc(c.address||'')}" placeholder="Адрес клиента">`;
 document.getElementById('address')?.focus();
}
function chooseMap(i){
 const c=db.clients[i];
 if(!c||!c.address)return;
 const clean=String(c.address).trim();
 const choice=prompt('Открыть адрес в:\n1 — 2ГИС\n2 — Яндекс Картах','1');
 if(window.Android&&Android.openMapChooser)Android.openMapChooser(clean);
}
function serviceHistoryList(i){
 const c=db.clients[i];
 if(!c)return;
 const items=Array.isArray(c.serviceHistory)?c.serviceHistory:[];
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">История обслуживания</div><div class="muted">${esc(c.name)||'Без имени'} · №${c.number}</div></div><button type="button" class="secondary" onclick="form(${i})">Назад</button></div>${items.length?items.slice().reverse().map((h,hi)=>{const realIndex=items.length-1-hi;return `<button type="button" class="historyItem" onclick="showServiceHistory(${i},${realIndex})"><span><b>${ruDate(h.date)}</b>${h.nextDate?`<div class="historyNext">Следующая замена: ${ruDate(h.nextDate)}</div>`:''}</span><span class="arrow">›</span></button>`}).join(''):'<div class="empty">История обслуживания пока пуста.</div>'}</div>`;
}

function extraPhoneHtml(p,i){return `<div class="extraPhone"><div class="phoneInputWrap"><input class="extraPhoneInput" inputmode="numeric" maxlength="15" value="${esc(phoneLocal(p))}" placeholder="8 705 560 75 87" oninput="formatPhoneField(this)"></div><button class="removeMini" onclick="this.parentElement.remove()">−</button></div>`}
function addExtraPhone(){document.getElementById('extraPhones').insertAdjacentHTML('beforeend',extraPhoneHtml('',Date.now()))}
function newClient(){form(-1)}function editClient(i){if(i>=0)form(i)}
function saveClient(i){
 const get = id => document.getElementById(id);
 const extra=[...document.querySelectorAll('.extraPhoneInput')].map(x=>phoneDigits(x.value)).filter(x=>x.length===11 && x.startsWith('8'));
 const cs=[...document.querySelectorAll('.car:checked')].map(x=>x.value);

 const client={
   number:i<0 ? db.nextClientNumber : db.clients[i].number,
   name:get('name').value.trim(),
   phone:phoneDigits(get('phone').value).length===11 && phoneDigits(get('phone').value).startsWith('8') ? phoneDigits(get('phone').value) : '',
   extraPhones:extra,
   address:(get('address')?.value||db.clients[i]?.address||'').trim(),
   model:get('model').value,
   cartridges:cs,
   install:get('install').value,
   replace:get('replace').value,
   notes:get('notes').value.trim(),
   serviceHistory: i<0 ? [] : (Array.isArray(db.clients[i].serviceHistory)?db.clients[i].serviceHistory:[]),
   completedDates: i<0 ? [] : (Array.isArray(db.clients[i].completedDates)?db.clients[i].completedDates:[])
 };

 if(!client.name && !client.phone){
   alert('Введите имя клиента или номер телефона.');
   return;
 }

 if(i<0){
   db.clients.push(client);
   db.nextClientNumber++;
 } else {
   db.clients[i]=client;
 }

 try {
   localStorage.setItem(KEY, JSON.stringify(db));
   clients();
 } catch(e) {
   alert('Не удалось сохранить клиента: ' + e.message);
 }
}
function addServiceRow(){document.getElementById('serviceRows').insertAdjacentHTML('beforeend',`<div class="grid serviceRow"><div><label>Картридж</label><select class="servicePart">${cartridges.map(x=>`<option>${x}</option>`).join('')}</select></div><div><label>Производитель</label><select class="serviceBrand">${brands.map(x=>`<option>${x}</option>`).join('')}</select></div></div>`)}
function addServiceRecord(i){
 if(i<0){alert('Сначала сохраните клиента.');return;}
 const rows=[...document.querySelectorAll('.serviceRow')];
 if(!rows.length){alert('Добавьте хотя бы один картридж.');return;}
 const date=document.getElementById('serviceDate').value||todayISO();
 const nextDate=document.getElementById('serviceNextDate').value||'';
 const comment=(document.getElementById('serviceComment').value||'').trim();
 const items=rows.map(r=>({part:r.querySelector('.servicePart').value,brand:r.querySelector('.serviceBrand').value}));
 if(!Array.isArray(db.clients[i].serviceHistory))db.clients[i].serviceHistory=[];
 db.clients[i].serviceHistory.push({date,nextDate,items,comment,completed:true});
 if(nextDate)db.clients[i].replace=nextDate;
 save();
 form(i);
}
function returnToClient(i){
 event?.preventDefault?.();
 event?.stopPropagation?.();
 form(i);
 return false;
}
function addEditServiceRow(part='',brand=''){
 const box=document.getElementById('editServiceRows');
 if(!box)return;
 box.insertAdjacentHTML('beforeend',`<div class="grid editServiceRow"><div><label>Картридж</label><select class="editServicePart">${cartridges.map(v=>`<option ${v===part?'selected':''}>${v}</option>`).join('')}</select></div><div><label>Производитель</label><select class="editServiceBrand">${brands.map(v=>`<option ${v===brand?'selected':''}>${v}</option>`).join('')}</select></div><button type="button" class="removeEditRow" onclick="this.parentElement.remove()">−</button></div>`);
}
function showServiceHistory(i,hIndex){
 const c=db.clients[i];
 if(!c||!Array.isArray(c.serviceHistory)||!c.serviceHistory[hIndex])return;
 const h=c.serviceHistory[hIndex];
 const items=Array.isArray(h.items)?h.items:[];
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">Обслуживание от ${ruDate(h.date)}</div></div><button type="button" class="secondary" onclick="serviceHistoryList(${i})">Назад</button></div>
 <label>Дата замены</label><input id="editServiceDate" type="date" value="${h.date||''}">
 <label>Дата следующей замены</label><input id="editServiceNextDate" type="date" value="${h.nextDate||''}">
 <div style="margin-top:10px"><div class="sectionTitle">Картриджи</div><div id="editServiceRows"></div></div>
 <label>Комментарий</label><textarea id="editServiceComment" rows="4" placeholder="Что сделали, замечания">${esc(h.comment||'')}</textarea>
 <button type="button" class="secondary small" onclick="addEditServiceRow()">+ Добавить картридж</button>
 <button type="button" onclick="saveServiceHistory(${i},${hIndex})">Сохранить изменения</button>
 <button type="button" class="secondary" onclick="serviceHistoryList(${i})">Назад</button></div>`;
 items.forEach(x=>addEditServiceRow(x.part||'',x.brand||''));
 if(!items.length)addEditServiceRow();
}
function saveServiceHistory(i,hIndex){
 const c=db.clients[i],h=c&&c.serviceHistory&&c.serviceHistory[hIndex];
 if(!h)return;
 const date=document.getElementById('editServiceDate').value||h.date;
 const nextDate=document.getElementById('editServiceNextDate').value||'';
 const rows=[...document.querySelectorAll('.editServiceRow')];
 h.date=date;h.nextDate=nextDate;h.items=rows.map(r=>({part:r.querySelector('.editServicePart').value,brand:r.querySelector('.editServiceBrand').value}));
 h.comment=(document.getElementById('editServiceComment').value||'').trim();
 if(nextDate)c.replace=nextDate;
 save();
 form(i);
}
function deleteClient(i){if(confirm('Удалить клиента №'+db.clients[i].number+'?')){db.clients.splice(i,1);save();clients()}}
function callClient(i){const phone=phoneDigits(db.clients[i].phone);if(window.Android&&Android.call){Android.call(phone);}else{location.href='tel:'+phone;}}
function wa(i){const phone=phoneForWhatsApp(db.clients[i].phone);if(window.Android)Android.whatsapp(phone);else location.href='https://wa.me/'+phone;}
function calendar(){
 const y=month.getFullYear(),m=month.getMonth(),first=new Date(y,m,1),days=new Date(y,m+1,0).getDate(),offset=(first.getDay()+6)%7;
 let h=`<div class="calendarCard"><div class="row" style="margin-bottom:8px"><div class="sectionTitle">Выберите дату</div><button type="button" class="secondary" onclick="home()">Назад</button></div><div class="calhead row"><button onclick="month.setMonth(month.getMonth()-1);calendar()">‹</button><b>${month.toLocaleDateString('ru-RU',{month:'long',year:'numeric'})}</b><button onclick="month.setMonth(month.getMonth()+1);calendar()">›</button></div><div class="week">${['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(x=>`<div>${x}</div>`).join('')}</div><div class="calendar">`;
 for(let i=0;i<offset;i++)h+='<div></div>';
 for(let d=1;d<=days;d++){let ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,arr=db.clients.filter(c=>c.replace===ds&&!(c.completedDates||[]).includes(ds)),today=new Date(),isToday=today.getFullYear()===y&&today.getMonth()===m&&today.getDate()===d;h+=`<div class="day ${arr.length?'has':''} ${isToday?'today':''}" onclick="showDate('${ds}')"><span class="dayNum">${d}</span>${arr.length?`<span class=count>${arr.length}</span>`:''}</div>`}
 h+='</div></div>';app.innerHTML=h;
}
function showDate(ds){const arr=db.clients.filter(c=>c.replace===ds);app.innerHTML=`<div class="card"><div class="row"><div class="sectionTitle">Заявки на ${ruDate(ds)}</div><button type="button" class="secondary" onclick="home()">Назад</button></div>${arr.length?arr.map(c=>`<div class="list"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">📞 ${esc(c.phone)} · 🏠 ${esc(c.address)||'—'}</div></div></div>`).join(''):'<div class="empty">На эту дату замен нет.</div>'}</div>`}
function backup(){app.innerHTML=`<div class="card"><div class="row"><div class="sectionTitle">Резервная копия</div><button type="button" class="secondary" onclick="home()">Назад</button></div><p class="muted">Сохраняется вся клиентская база, номера клиентов, телефоны, адреса, фильтры, картриджи и даты.</p><button onclick="Android.backup(JSON.stringify(db))">Сохранить резервную копию</button><button class="secondary" onclick="Android.restore()">Восстановить из файла</button></div>`}
function restoreBackup(s){try{const x=JSON.parse(s);if(!x||!Array.isArray(x.clients))throw 0;db=x;db.clients.forEach(c=>{delete c.mineralizer;delete c.postfilter;delete c.pp100;});if(!Number.isInteger(db.nextClientNumber))db.nextClientNumber=db.clients.reduce((m,c)=>Math.max(m,Number(c.number)||0),0)+1;save();home();alert('База восстановлена')}catch(e){alert('Не удалось восстановить резервную копию')}}
initTopDate();
setInterval(()=>{initTopDate();updateHomeCounters();},60000);
home();
