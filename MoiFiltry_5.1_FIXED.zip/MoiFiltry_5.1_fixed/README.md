# Мои Фильтры 5.1

Android-проект приложения «Мои Фильтры».

Сборка:
`gradle assembleDebug --stacktrace --no-daemon`

APK:
`app/build/outputs/apk/debug/app-debug.apk`
