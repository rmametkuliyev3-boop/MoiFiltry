# ProGuard rules for MoiFiltry
# No custom shrinking rules required.
