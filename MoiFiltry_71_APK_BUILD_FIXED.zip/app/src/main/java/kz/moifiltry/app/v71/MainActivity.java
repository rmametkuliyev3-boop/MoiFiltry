package kz.moifiltry.app.v71;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_SAVE = 4101;
    private static final int REQ_RESTORE = 4102;
    private String pendingBackup = null;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public void call(String number) {
            try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:+" + number))); }
            catch (Exception e) { Toast.makeText(MainActivity.this, "Не удалось открыть звонок", Toast.LENGTH_SHORT).show(); }
        }
        @JavascriptInterface public void whatsapp(String number) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + number))); }
            catch (Exception e) { Toast.makeText(MainActivity.this, "Не удалось открыть WhatsApp", Toast.LENGTH_SHORT).show(); }
        }
        @JavascriptInterface public void openMapChooser(String address) {
            String q = Uri.encode(address);
            Intent chooser = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + q));
            try { startActivity(Intent.createChooser(chooser, "Открыть адрес в карте")); }
            catch (Exception e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + q))); }
        }
        @JavascriptInterface public void backup(String json) {
            pendingBackup = json;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE, "MoiFiltry_backup.json");
            startActivityForResult(i, REQ_SAVE);
        }
        @JavascriptInterface public void restore() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("application/json");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_RESTORE);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        try {
            if (requestCode == REQ_SAVE && pendingBackup != null) {
                Uri uri = data.getData();
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this, "Резервная копия сохранена", Toast.LENGTH_SHORT).show();
                pendingBackup = null;
            } else if (requestCode == REQ_RESTORE) {
                StringBuilder b = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(data.getData());
                     BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line; while ((line = r.readLine()) != null) b.append(line);
                }
                String json = b.toString().replace("\\", "\\\\").replace("'", "\\'");
                webView.evaluateJavascript("restoreBackup('" + json + "')", null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось выполнить операцию", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("handleAndroidBack()", value -> {
                if (value == null || value.contains("exit")) MainActivity.super.onBackPressed();
            });
        } else super.onBackPressed();
    }
}
