
const KEY='moifiltry5';
let db=JSON.parse(localStorage.getItem(KEY)||'null');
if(!db) db={clients:[],nextClientNumber:1};
if(!Array.isArray(db.clients)) db.clients=[];
// 5.1: remove legacy fields that are no longer used in the interface.
db.clients.forEach(c=>{delete c.mineralizer;delete c.postfilter;delete c.pp100;});
if(!Number.isInteger(db.nextClientNumber)||db.nextClientNumber<1) db.nextClientNumber=(db.clients.reduce((m,c)=>Math.max(m,Number(c.number)||0),0)+1);
let month=new Date();month.setDate(1);
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const save=()=>localStorage.setItem(KEY,JSON.stringify(db));
const models=['Ecosoft с насосом','Ecosoft без насоса','FitAqua с насосом','FitAqua без насоса','Другое'];
const cartridges=['PP5','GAC','CTO','PP1','Пост-фильтр','Минерализатор','RO-мембрана'];
const brands=['Вастерлайн','Ecosoft','FitAqua'];
function toggleMenu(){document.getElementById('menu').classList.toggle('open')}
function closeMenu(){document.getElementById('menu').classList.remove('open')}
function todayISO(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function ruDate(ds){if(!ds)return '—';const [y,m,d]=ds.split('-');return `${d}.${m}.${y}`}
function initTopDate(){document.getElementById('topDate').textContent='📅 '+ruDate(todayISO());}
function openTopCalendar(){calendar();showDate(todayISO());}
function clients(){
 const q=(document.getElementById('search')?.value||'').toLowerCase();
 const arr=db.clients.filter(c=>[c.name,c.phone,c.address,c.model,String(c.number)].join(' ').toLowerCase().includes(q));
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">Клиентская база</div><div class="stat">${db.clients.length}</div><div class="muted">Всего клиентов</div></div><button onclick="newClient()">+ Новый клиент</button></div></div>
 <div class="card"><input id="search" class="search" placeholder="Поиск клиента: имя, телефон, адрес или №" value="${esc(q)}" oninput="clients()"></div>`+
 (arr.length?arr.map(c=>`<div class="card client" onclick="editClientByNumber(${c.number})"><div class="row"><b>№${c.number} — ${esc(c.name)||'Без имени'}</b><span class="muted">${esc(formatPhoneDisplay(c.phone))}</span></div><div>${c.model?`<span class=pill>${esc(c.model)}</span>`:''}${(c.cartridges||[]).map(x=>`<span class=pill>${esc(x)}</span>`).join('')}</div><div class="muted">🏠 ${esc(c.address)||'Адрес не указан'}</div><div class="muted">Установка: ${c.install||'—'} · Следующая замена: ${c.replace||'—'}</div></div>`).join(''):`<div class="card empty">Ничего не найдено.</div>`);
}
function home(){
 const today=todayISO();
 const todayTasks=db.clients.filter(c=>c.replace===today);
 const overdue=db.clients.filter(c=>c.replace && c.replace<today && !(c.completedDates||[]).includes(c.replace));
 app.innerHTML=`<div class="card"><button class="dateButton" onclick="showDate('${today}',true)">📅 Сегодня · ${ruDate(today)}</button><div class="circleRow"><div class="taskCircle" onclick="showDate('${today}',true)"><b>${todayTasks.length}</b></div><div class="taskCircle overdue" onclick="showOverdue()"><b>${overdue.length}</b></div></div></div><div class="card"><input id="homeSearch" class="search" placeholder="Поиск клиента" oninput="homeSearch()"></div><div id="homeResults"></div><div class="card"><div class="sectionTitle">Заявки на сегодня</div>${todayTasks.length?todayTasks.map(c=>`<div class="list"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">Замена: ${ruDate(c.replace)}</div></div></div>`).join(''):'<div class="empty">На сегодня заявок нет.</div>'}</div>`;
}
function homeSearch(){const q=(document.getElementById('homeSearch')?.value||'').toLowerCase();const box=document.getElementById('homeResults');if(!q){box.innerHTML='';return;}const arr=db.clients.filter(c=>[c.name,c.phone,c.address,c.model,String(c.number)].join(' ').toLowerCase().includes(q));box.innerHTML=arr.length?`<div class="card">${arr.map(c=>`<div class="list" onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)||'Без имени'}</b><div class="muted">${esc(formatPhoneDisplay(c.phone))} · ${esc(c.address)||'Адрес не указан'}</div></div>`).join('')}</div>`:'<div class="card empty">Клиент не найден.</div>'}
function showOverdue(){const today=todayISO();const arr=db.clients.filter(c=>c.replace&&c.replace<today&&!(c.completedDates||[]).includes(c.replace));app.innerHTML=`<div class="card"><div class="sectionTitle">Просроченные</div>${arr.length?arr.map(c=>`<div class="list"><div class="row"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">Просрочено с ${ruDate(c.replace)}</div></div><button class="small" onclick="completeTask(${c.number},'${c.replace}')">Выполнено</button></div></div>`).join(''):'<div class="empty">Просроченных заявок нет.</div>'}</div>`}
function completeTask(n,ds){const i=getIndexByNumber(n);if(i<0)return;if(!Array.isArray(db.clients[i].completedDates))db.clients[i].completedDates=[];if(!db.clients[i].completedDates.includes(ds))db.clients[i].completedDates.push(ds);save();home()}

function getIndexByNumber(n){return db.clients.findIndex(c=>Number(c.number)===Number(n))}
function editClientByNumber(n){editClient(getIndexByNumber(n))}
function phoneDigits(value){
 const d=String(value||'').replace(/\D/g,'');
 if(d.startsWith('7') && d.length>=11) return d.slice(1,11);
 if(d.startsWith('8') && d.length>=11) return d.slice(1,11);
 return d.slice(0,10);
}
function phoneLocal(value){return phoneDigits(value)}
function formatPhoneField(el){
 let d=phoneDigits(el.value);
 let out=d;
 if(d.length>3) out=d.slice(0,3)+' '+d.slice(3);
 if(d.length>6) out=d.slice(0,3)+' '+d.slice(3,6)+' '+d.slice(6);
 if(d.length>8) out=d.slice(0,3)+' '+d.slice(3,6)+' '+d.slice(6,8)+' '+d.slice(8);
 el.value=out;
}
function formatPhoneDisplay(value){
 const d=phoneDigits(value);
 if(!d) return '';
 let out=d;
 if(d.length>3) out=d.slice(0,3)+' '+d.slice(3);
 if(d.length>6) out=d.slice(0,3)+' '+d.slice(3,6)+' '+d.slice(6);
 if(d.length>8) out=d.slice(0,3)+' '+d.slice(3,6)+' '+d.slice(6,8)+' '+d.slice(8);
 return '+7 '+out;
}
function form(i){
 const c=i<0?{number:db.nextClientNumber,name:'',phone:'',extraPhones:[],address:'',model:'Ecosoft с насосом',cartridges:[],install:'',replace:'',notes:'',serviceHistory:[]}:db.clients[i];
 if(!Array.isArray(c.serviceHistory))c.serviceHistory=[];
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">${i<0?'Новый клиент':'Карточка клиента'}</div><div class="muted">№${c.number}</div></div><button class="secondary" onclick="clients()">Назад</button></div>
 <label>Имя клиента</label><input id="name" value="${esc(c.name)}" placeholder="Имя и фамилия">
 <label>Основной телефон</label><div class="phoneRow"><div class="phoneInputWrap"><span>+7</span><input id="phone" inputmode="numeric" maxlength="13" value="${esc(phoneLocal(c.phone))}" placeholder="705 123 45 67" oninput="formatPhoneField(this)"></div><button class="plusMini" onclick="addExtraPhone()">+</button></div>
 <div id="extraPhones">${(c.extraPhones||[]).map((p,i)=>extraPhoneHtml(p,i)).join('')}</div>
 <label>Адрес</label><input id="address" value="${esc(c.address)}" placeholder="Адрес клиента">
 <label>Фильтр / модель</label><select id="model">${models.map(x=>`<option ${x===c.model?'selected':''}>${x}</option>`).join('')}</select>
 <label>Картриджи</label><div>${cartridges.map(x=>`<label style="display:block;font-weight:400"><input class="car" type="checkbox" value="${x}" ${(c.cartridges||[]).includes(x)?'checked':''} style="width:auto;margin-right:7px">${x}</label>`).join('')}</div>
 <div class="grid"><div><label>Дата установки</label><input id="install" type="date" value="${c.install||''}"></div><div><label>Дата следующей замены</label><input id="replace" type="date" value="${c.replace||''}"></div></div>
 <div class="card" style="margin:12px 0;padding:12px;background:#f7f9fc"><div class="sectionTitle">История замен</div>${c.serviceHistory.length?c.serviceHistory.slice().reverse().map((h,hi)=>`<div class="list"><b>${ruDate(h.date)}</b>${(h.items||[]).map(x=>`<div class="muted">${esc(x.part)} — ${esc(x.brand)}</div>`).join('')}</div>`).join(''):'<div class="empty">Замены пока не записаны.</div>'}<div style="margin-top:10px"><label>Новая замена</label><input id="serviceDate" type="date" value="${todayISO()}"><div id="serviceRows"></div><button class="secondary small" onclick="addServiceRow()">+ Добавить картридж</button><button class="small" onclick="addServiceRecord(${i})">Записать замену</button></div></div>
 <label>Примечание</label><textarea id="notes" rows="4" placeholder="Дополнительная информация">${esc(c.notes)}</textarea>
 <button onclick="saveClient(${i})">Сохранить клиента</button>${i>=0?`<button onclick="callClient(${i})" class="secondary">Позвонить</button><button onclick="wa(${i})" class="secondary">WhatsApp</button><button onclick="deleteClient(${i})" class="danger">Удалить</button>`:''}</div>`;
 addServiceRow();
}
function extraPhoneHtml(p,i){return `<div class="extraPhone"><div class="phoneInputWrap"><span>+7</span><input class="extraPhoneInput" inputmode="numeric" maxlength="13" value="${esc(phoneLocal(p))}" placeholder="705 123 45 67" oninput="formatPhoneField(this)"></div><button class="removeMini" onclick="this.parentElement.remove()">−</button></div>`}
function addExtraPhone(){document.getElementById('extraPhones').insertAdjacentHTML('beforeend',extraPhoneHtml('',Date.now()))}
function newClient(){form(-1)}function editClient(i){if(i>=0)form(i)}
function saveClient(i){
 const get = id => document.getElementById(id);
 const extra=[...document.querySelectorAll('.extraPhoneInput')].map(x=>phoneDigits(x.value)).filter(x=>x.length===10).map(x=>'+7'+x);
 const cs=[...document.querySelectorAll('.car:checked')].map(x=>x.value);

 const client={
   number:i<0 ? db.nextClientNumber : db.clients[i].number,
   name:get('name').value.trim(),
   phone:phoneDigits(get('phone').value).length===10 ? '+7'+phoneDigits(get('phone').value) : '',
   extraPhones:extra,
   address:get('address').value.trim(),
   model:get('model').value,
   cartridges:cs,
   install:get('install').value,
   replace:get('replace').value,
   notes:get('notes').value.trim(),
   serviceHistory: i<0 ? [] : (Array.isArray(db.clients[i].serviceHistory)?db.clients[i].serviceHistory:[]),
   completedDates: i<0 ? [] : (Array.isArray(db.clients[i].completedDates)?db.clients[i].completedDates:[])
 };

 if(!client.name && !client.phone){
   alert('Введите имя клиента или номер телефона.');
   return;
 }

 if(i<0){
   db.clients.push(client);
   db.nextClientNumber++;
 } else {
   db.clients[i]=client;
 }

 try {
   localStorage.setItem(KEY, JSON.stringify(db));
   clients();
 } catch(e) {
   alert('Не удалось сохранить клиента: ' + e.message);
 }
}
function addServiceRow(){document.getElementById('serviceRows').insertAdjacentHTML('beforeend',`<div class="grid serviceRow"><div><label>Картридж</label><select class="servicePart">${cartridges.map(x=>`<option>${x}</option>`).join('')}</select></div><div><label>Производитель</label><select class="serviceBrand">${brands.map(x=>`<option>${x}</option>`).join('')}</select></div></div>`)}
function addServiceRecord(i){if(i<0){alert('Сначала сохраните клиента.');return;}const rows=[...document.querySelectorAll('.serviceRow')];if(!rows.length){alert('Добавьте хотя бы один картридж.');return;}const date=document.getElementById('serviceDate').value||todayISO();const items=rows.map(r=>({part:r.querySelector('.servicePart').value,brand:r.querySelector('.serviceBrand').value}));if(!Array.isArray(db.clients[i].serviceHistory))db.clients[i].serviceHistory=[];db.clients[i].serviceHistory.push({date,items});save();form(i)}
function deleteClient(i){if(confirm('Удалить клиента №'+db.clients[i].number+'?')){db.clients.splice(i,1);save();clients()}}
function callClient(i){if(window.Android&&Android.call){Android.call('+7'+phoneDigits(db.clients[i].phone));}else{location.href='tel:'+('+7'+phoneDigits(db.clients[i].phone));}}
function wa(i){if(window.Android)Android.whatsapp('+7'+phoneDigits(db.clients[i].phone))}
function calendar(){
 const y=month.getFullYear(),m=month.getMonth(),first=new Date(y,m,1),days=new Date(y,m+1,0).getDate(),offset=(first.getDay()+6)%7;
 let h=`<div class="card"><div class="calhead row"><button onclick="month.setMonth(month.getMonth()-1);calendar()">‹</button><b>${month.toLocaleDateString('ru-RU',{month:'long',year:'numeric'})}</b><button onclick="month.setMonth(month.getMonth()+1);calendar()">›</button></div><div class="week">${['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(x=>`<div>${x}</div>`).join('')}</div><div class="calendar">`;
 for(let i=0;i<offset;i++)h+='<div></div>';
 for(let d=1;d<=days;d++){let ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,arr=db.clients.filter(c=>c.replace===ds),today=new Date(),isToday=today.getFullYear()===y&&today.getMonth()===m&&today.getDate()===d;h+=`<div class="day ${arr.length?'has':''} ${isToday?'today':''}" onclick="showDate('${ds}')"><b>${d}</b>${arr.length?`<div class=count>${arr.length} кл.</div>`:''}</div>`}
 h+='</div></div><div id="dateList"></div>';app.innerHTML=h;
}
function showDate(ds){const arr=db.clients.filter(c=>c.replace===ds);let box=document.getElementById('dateList');if(!box){box=document.createElement('div');box.id='dateList';app.appendChild(box)}box.innerHTML=`<div class="card"><div class="sectionTitle">Замены на ${ds}</div>${arr.length?arr.map(c=>`<div class="list"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">📞 ${esc(c.phone)} · 🏠 ${esc(c.address)||'—'}</div></div></div>`).join(''):'<div class="empty">На эту дату замен нет.</div>'}</div>`}
function backup(){app.innerHTML=`<div class="card"><div class="sectionTitle">Резервная копия</div><p class="muted">Сохраняется вся клиентская база, номера клиентов, телефоны, адреса, фильтры, картриджи и даты.</p><button onclick="Android.backup(JSON.stringify(db))">Сохранить резервную копию</button><button class="secondary" onclick="Android.restore()">Восстановить из файла</button></div>`}
function restoreBackup(s){try{const x=JSON.parse(s);if(!x||!Array.isArray(x.clients))throw 0;db=x;db.clients.forEach(c=>{delete c.mineralizer;delete c.postfilter;delete c.pp100;});if(!Number.isInteger(db.nextClientNumber))db.nextClientNumber=db.clients.reduce((m,c)=>Math.max(m,Number(c.number)||0),0)+1;save();home();alert('База восстановлена')}catch(e){alert('Не удалось восстановить резервную копию')}}
initTopDate();
home();
