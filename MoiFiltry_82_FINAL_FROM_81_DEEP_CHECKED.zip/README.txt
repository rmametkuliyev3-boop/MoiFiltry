MoiFiltry 8.2 — источник проекта

Версия проекта: 8.2, applicationId kz.moifiltry.app.v82.
База изменений: MoiFiltry 81.
