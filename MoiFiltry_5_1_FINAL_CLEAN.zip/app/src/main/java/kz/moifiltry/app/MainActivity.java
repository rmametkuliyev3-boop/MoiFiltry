package kz.moifiltry.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private String pendingBackup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void backup(String json) {
            pendingBackup = json;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "MoiFiltry_backup.json");
            startActivityForResult(intent, 100);
        }

        @JavascriptInterface
        public void restore() {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("application/json");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, 101);
        }

        @JavascriptInterface
        public void whatsapp(String phone) {
            String digits = phone.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://wa.me/" + digits)));
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;

        try {
            if (requestCode == 100) {
                OutputStream out = getContentResolver().openOutputStream(data.getData());
                if (out != null) {
                    out.write(pendingBackup.getBytes("UTF-8"));
                    out.close();
                }
                webView.evaluateJavascript(
                        "alert('Резервная копия сохранена');", null);
            } else if (requestCode == 101) {
                InputStream in = getContentResolver().openInputStream(data.getData());
                BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                StringBuilder json = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) json.append(line);
                reader.close();

                String safeJson = org.json.JSONObject.quote(json.toString());
                webView.evaluateJavascript("restoreBackup(" + safeJson + ")", null);
            }
        } catch (Exception e) {
            webView.evaluateJavascript(
                    "alert('Не удалось выполнить операцию с резервной копией');", null);
        }
    }
}
