
const KEY='moifiltry5';
let db=JSON.parse(localStorage.getItem(KEY)||'null');
if(!db) db={clients:[],nextClientNumber:1};
if(!Array.isArray(db.clients)) db.clients=[];
// 5.1: remove legacy fields that are no longer used in the interface.
db.clients.forEach(c=>{delete c.mineralizer;delete c.postfilter;delete c.pp100;c.extraPhones=(Array.isArray(c.extraPhones)?c.extraPhones:[]).map(p=>typeof p==='string'?{name:'',phone:p}:{name:String(p?.name||''),phone:String(p?.phone||'')}).filter(p=>p.phone||p.name);});
if(!Number.isInteger(db.nextClientNumber)||db.nextClientNumber<1) db.nextClientNumber=(db.clients.reduce((m,c)=>Math.max(m,Number(c.number)||0),0)+1);
let month=new Date();month.setDate(1);
let homeSearchOpen=false;
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const save=()=>localStorage.setItem(KEY,JSON.stringify(db));
const models=['Ecosoft с насосом','Ecosoft без насоса','FitAqua с насосом','FitAqua без насоса','Другое'];
const cartridges=['PP5','GAC','CTO','PP1','Пост-фильтр','Минерализатор','RO-мембрана'];
const brands=['Вастерлайн','Ecosoft','FitAqua'];
function hideHomeCounters(){}
function toggleMenu(){document.getElementById('menu').classList.toggle('open')}
function closeMenu(){document.getElementById('menu').classList.remove('open')}
function todayISO(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function ruDate(ds){if(!ds)return '—';const [y,m,d]=ds.split('-');return `${d}.${m}.${y}`}
function initTopDate(){document.getElementById('topDate').textContent='📅 '+ruDate(todayISO());}
function openTopCalendar(){calendar();}
function isOverdue(c){const t=todayISO();return !!(c.replace&&c.replace<t&&!(c.completedDates||[]).includes(c.replace))}
function updateHomeCounters(){
 const box=document.getElementById('homeCounters');
 if(!box)return;
 const t=todayISO();
 const todayCount=db.clients.filter(c=>c.replace===t&&!(c.completedDates||[]).includes(c.replace)).length;
 const overdueCount=db.clients.filter(isOverdue).length;
 document.getElementById('todayCounter').textContent=todayCount;
 document.getElementById('overdueCounter').textContent=overdueCount;
}
function toggleHomeSearch(){
 if(!app.innerHTML.includes('id="homeSearch"')){filterHome();homeSearchOpen=true;filterHome();}
 else {homeSearchOpen=!homeSearchOpen;filterHome();}
}

function clients(){
 setScreen('clients'); setShell('filters');
 const q=(document.getElementById('search')?.value||'').toLowerCase();
 const arr=db.clients.filter(c=>[c.name,c.phone,c.address,c.model,String(c.number),(c.extraPhones||[]).map(p=>typeof p==='string'?p:(p.name+' '+p.phone)).join(' ')].join(' ').toLowerCase().includes(q));
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">Клиентская база</div><div class="stat">${db.clients.length}</div><div class="muted">Всего клиентов</div></div><div><button type="button" class="secondary" onclick="home()">Назад</button><button onclick="newClient()">+ Новый клиент</button></div></div></div>
 <div class="card"><input id="search" class="search" placeholder="Поиск клиента: имя, телефон, адрес или №" value="${esc(q)}" oninput="clients()"></div>`+
 (arr.length?arr.map(c=>`<div class="card client" onclick="editClientByNumber(${c.number})"><div class="row"><b>№${c.number} — ${esc(c.name)||'Без имени'}</b><span class="muted">${esc(formatPhoneDisplay(c.phone))}</span></div><div>${c.model?`<span class=pill>${esc(c.model)}</span>`:''}${(c.cartridges||[]).map(x=>`<span class=pill>${esc(x)}</span>`).join('')}</div><div class="muted">🏠 ${esc(c.address)||'Адрес не указан'}</div><div class="muted">Установка: ${c.install||'—'} · Следующая замена: ${c.replace||'—'}</div></div>`).join(''):`<div class="card empty">Ничего не найдено.</div>`);
}
function filterHome(){
 setScreen('filterHome'); setShell('filters');
 const today=todayISO();
 const todayTasks=db.clients.filter(c=>c.replace===today&&!(c.completedDates||[]).includes(c.replace));
 const overdue=db.clients.filter(isOverdue);
 app.innerHTML=`${homeSearchOpen?`<div class="card"><input id="homeSearch" class="search" placeholder="Поиск клиента" oninput="homeSearch()" autofocus></div><div id="homeResults"></div>`:''}${todayTasks.length?`<div class="card"><div class="sectionTitle">Заявки на сегодня</div>${todayTasks.map(c=>`<div class="list"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">Замена: ${ruDate(c.replace)}</div></div></div>`).join('')}</div>`:''}`;
 const counters=document.getElementById('homeCounters');
 if(counters)counters.classList.add('open');
 updateHomeCounters();
}
function homeSearch(){const q=(document.getElementById('homeSearch')?.value||'').toLowerCase();const box=document.getElementById('homeResults');if(!box)return;if(!q){box.innerHTML='';return;}const arr=db.clients.filter(c=>[c.name,c.phone,c.address,c.model,String(c.number),(c.extraPhones||[]).map(p=>typeof p==='string'?p:(p.name+' '+p.phone)).join(' ')].join(' ').toLowerCase().includes(q));box.innerHTML=arr.length?`<div class="card">${arr.map(c=>`<div class="list" onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)||'Без имени'}</b><div class="muted">${esc(formatPhoneDisplay(c.phone))} · ${esc(c.address)||'Адрес не указан'}</div></div>`).join('')}</div>`:'<div class="card empty">Клиент не найден.</div>'}
function showOverdue(){
 setScreen('overdue');const arr=db.clients.filter(isOverdue);app.innerHTML=`<div class="card"><div class="row"><div class="sectionTitle">Просроченные</div><button type="button" class="secondary" onclick="home()">Назад</button></div>${arr.length?arr.map(c=>`<div class="list"><div class="row"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">Просрочено с ${ruDate(c.replace)}</div></div><button class="small" onclick="completeTask(${c.number},'${c.replace}')">Выполнено</button></div></div>`).join(''):'<div class="empty">Просроченных заявок нет.</div>'}</div>`}
function completeCurrentTask(i){const c=db.clients[i];if(!c||!isOverdue(c))return;completeTask(c.number,c.replace)}
function completeTask(n,ds){
 const i=getIndexByNumber(n);if(i<0)return;
 const c=db.clients[i];
 if(!Array.isArray(c.completedDates))c.completedDates=[];
 if(c.completedDates.includes(ds))return;
 c.completedDates.push(ds);
 if(!Array.isArray(c.serviceHistory))c.serviceHistory=[];
 const known={};
 c.serviceHistory.forEach(h=>(h.items||[]).forEach(x=>{if(x.part&&x.brand)known[x.part]=x.brand;}));
 const items=(c.cartridges||[]).map(part=>({part,brand:known[part]||'Не указан'}));
 c.serviceHistory.push({date:ds,items,completed:true});
 save();filterHome();
}

function getIndexByNumber(n){return db.clients.findIndex(c=>Number(c.number)===Number(n))}
function editClientByNumber(n){editClient(getIndexByNumber(n))}
function phoneDigits(value){
 let d=String(value||'').replace(/\D/g,'');
 if(d.startsWith('00')) d=d.slice(2);
 if(d.startsWith('7') && d.length===11) d='8'+d.slice(1);
 if(d.startsWith('8')) return d.slice(0,11);
 return d.slice(0,11);
}
function phoneLocal(value){return phoneDigits(value)}
function formatPhoneField(el){
 const d=phoneDigits(el.value);
 let out=d;
 if(d.length>1) out=d.slice(0,1)+' '+d.slice(1);
 if(d.length>4) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4);
 if(d.length>7) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7);
 if(d.length>9) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7,9)+' '+d.slice(9,11);
 el.value=out;
}
function formatPhoneDisplay(value){
 const d=phoneDigits(value);
 if(!d) return '';
 let out=d;
 if(d.length>1) out=d.slice(0,1)+' '+d.slice(1);
 if(d.length>4) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4);
 if(d.length>7) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7);
 if(d.length>9) out=d.slice(0,1)+' '+d.slice(1,4)+' '+d.slice(4,7)+' '+d.slice(7,9)+' '+d.slice(9,11);
 return out;
}
function phoneIcon(type){
 if(type==='wa') return '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#fff" d="M20.5 3.5A11.4 11.4 0 0 0 12.4 0C6.1 0 1 5.1 1 11.4c0 2 .5 4 1.5 5.7L.9 23l6-1.6a11.3 11.3 0 0 0 5.5 1.4h.1C18.8 22.8 24 17.7 24 11.4c0-3-1.2-5.8-3.5-7.9Zm-8.1 17.3h-.1c-1.7 0-3.4-.5-4.8-1.3l-.3-.2-3.5.9.9-3.4-.2-.3a9.4 9.4 0 1 1 8 4.3Zm5.2-7.1c-.3-.2-1.7-.8-2-.9-.3-.1-.5-.2-.7.2-.2.3-.8.9-.9 1.1-.2.2-.3.2-.6.1-1.5-.7-2.5-1.3-3.5-2.9-.3-.5.3-.4.8-1.4.1-.2.1-.4 0-.6-.1-.2-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.2 1.1-1.2 2.7s1.2 3.1 1.4 3.3c.2.2 2.3 3.5 5.6 4.9 2.1.9 2.1.6 2.5.6.4 0 1.7-.7 2-1.3.2-.6.2-1.1.1-1.2-.1-.1-.3-.2-.6-.3Z"/></svg>';
 return '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#fff" d="M6.6 2.2 8.9 2c.5 0 .9.3 1.1.7l1.3 3.1c.2.4.1.9-.2 1.2L9.7 7.8c.8 1.7 2.1 3.1 3.8 3.9l.8-1.4c.3-.4.7-.5 1.2-.3l3.1 1.3c.4.2.7.6.7 1.1l-.2 2.3c-.1.8-.8 1.5-1.6 1.6-.6.1-1.2.1-1.8 0-5.9-.9-10.5-5.5-11.4-11.4-.1-.6-.1-1.2 0-1.8.1-.8.8-1.5 1.6-1.6Z"/></svg>';
}
function contactActions(phone, index, extra){
 const p=phoneDigits(phone||'');
 if(p.length!==11) return '';
 const callFn=extra ? `callExtraContact(${index})` : `callPhoneValue('${p}')`;
 const waFn=extra ? `waExtraContact(${index})` : `waPhoneValue('${p}')`;
 return `<div class="contactActions"><button type="button" class="contactIcon callIcon" onclick="${callFn}" aria-label="Позвонить">${phoneIcon('call')}</button><button type="button" class="contactIcon waIcon" onclick="${waFn}" aria-label="WhatsApp">${phoneIcon('wa')}</button></div>`;
}
function form(i){
 setScreen('client'); setShell('filters');
 const c=i<0?{number:db.nextClientNumber,name:'',phone:'',extraPhones:[],address:'',model:'Ecosoft с насосом',cartridges:[],install:'',replace:'',notes:'',serviceHistory:[]}:db.clients[i];
 if(!Array.isArray(c.serviceHistory))c.serviceHistory=[];
 const addressBlock=c.address?`<div class="addressRow"><button type="button" class="addressLink" onclick="chooseMap(${i})">🏠 ${esc(c.address)}</button><button type="button" class="secondary small addressEdit" onclick="editAddressField(${i})">Изменить</button></div>`:`<input id="address" value="" placeholder="Адрес клиента">`;
 const extraContacts=(c.extraPhones||[]).map((p,idx)=>{const obj=typeof p==='string'?{name:'',phone:p}:(p||{});return extraPhoneHtml(obj.phone||'',idx,obj.name||'');}).join('');
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">${i<0?'Новый клиент':'Карточка клиента'}</div><div class="muted">№${c.number}</div></div><button type="button" class="secondary" onclick="clients()">Назад</button></div>
 <label>Основной контакт</label><div class="contactBlock"><div class="contactName"><input id="name" value="${esc(c.name)}" placeholder="Имя и фамилия"></div><div class="contactPhoneRow"><div class="phoneInputWrap"><input id="phone" inputmode="numeric" maxlength="15" value="${esc(phoneLocal(c.phone))}" placeholder="8 705 560 75 87" oninput="formatPhoneField(this)"></div>${contactActions(c.phone,i,false)}<button type="button" class="plusMini" onclick="addExtraPhone()" aria-label="Добавить контакт">+</button></div></div>
 <div id="extraPhones">${extraContacts}</div>
 <label>Адрес</label>${addressBlock}
 <label>Фильтр / модель</label><select id="model">${models.map(x=>`<option ${x===c.model?'selected':''}>${x}</option>`).join('')}</select>
 <label>Картриджи</label><div>${cartridges.map(x=>`<label style="display:block;font-weight:400"><input class="car" type="checkbox" value="${x}" ${(c.cartridges||[]).includes(x)?'checked':''} style="width:auto;margin-right:7px">${x}</label>`).join('')}</div>
 <div><label>Дата установки</label><input id="install" type="date" value="${c.install||''}"></div>
 <div class="card" style="margin:12px 0;padding:12px;background:#f7f9fc"><div class="sectionTitle">История обслуживания</div><button type="button" class="historyMenu" onclick="serviceHistoryList(${i})"><span>История обслуживания</span><span class="arrow">›</span></button><div style="margin-top:10px"><label>Новая замена</label><div class="grid serviceDateGrid"><div><label>Дата замены</label><input id="serviceDate" type="date" value="${todayISO()}"></div><div><label>Дата следующей замены</label><input id="serviceNextDate" type="date" value="${c.replace||''}"></div></div><div id="serviceRows"></div><label>Комментарий к замене</label><textarea id="serviceComment" rows="3" placeholder="Что сделали, замечания"></textarea><button class="secondary small" onclick="addServiceRow()">+ Добавить картридж</button><button class="small" onclick="addServiceRecord(${i})">Записать замену</button></div></div>
 <label>Примечание</label><textarea id="notes" rows="4" placeholder="Дополнительная информация">${esc(c.notes)}</textarea>
 <button type="button" onclick="saveClient(${i})">Сохранить клиента</button>${i>=0?`${isOverdue(c)?`<button type="button" onclick="completeCurrentTask(${i})" class="secondary">Выполнено</button>`:''}<button type="button" onclick="deleteClient(${i})" class="danger">Удалить</button>`:''}</div>`;
 addServiceRow();
}

function editAddressField(i){
 const c=db.clients[i];
 if(!c)return;
 const box=document.querySelector('.addressRow');
 if(!box)return;
 box.outerHTML=`<input id="address" value="${esc(c.address||'')}" placeholder="Адрес клиента">`;
 document.getElementById('address')?.focus();
}
function chooseMap(i){
 const c=db.clients[i];
 if(!c||!c.address)return;
 const clean=String(c.address).trim();
 const choice=prompt('Открыть адрес в:\n1 — 2ГИС\n2 — Яндекс Картах','1');
 if(window.Android&&Android.openMapChooser)Android.openMapChooser(clean);
}
function serviceHistoryList(i){
 setScreen('history');
 const c=db.clients[i];
 if(!c)return;
 const items=Array.isArray(c.serviceHistory)?c.serviceHistory:[];
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">История обслуживания</div><div class="muted">${esc(c.name)||'Без имени'} · №${c.number}</div></div><button type="button" class="secondary" onclick="returnToClientCard(${i})">Назад</button></div>${items.length?items.slice().reverse().map((h,hi)=>{const realIndex=items.length-1-hi;return `<button type="button" class="historyItem" onclick="showServiceHistory(${i},${realIndex})"><span><b>${ruDate(h.date)}</b>${h.nextDate?`<div class="historyNext">Следующая замена: ${ruDate(h.nextDate)}</div>`:''}</span><span class="arrow">›</span></button>`}).join(''):'<div class="empty">История обслуживания пока пуста.</div>'}</div>`;
}

function extraPhoneHtml(p,i,name=''){
 const n=esc(name||'');
 const value=esc(phoneLocal(p));
 return `<div class="contactBlock extraContact"><div class="contactName"><input class="extraContactName" value="${n}" placeholder="Имя контакта"></div><div class="contactPhoneRow"><div class="phoneInputWrap"><input class="extraPhoneInput" inputmode="numeric" maxlength="15" value="${value}" placeholder="8 705 560 75 87" oninput="formatPhoneField(this)"></div>${contactActions(p,i,true)}<button type="button" class="removeMini" onclick="this.parentElement.parentElement.remove()" aria-label="Удалить контакт">−</button></div></div>`;
}
function addExtraPhone(){document.getElementById('extraPhones').insertAdjacentHTML('beforeend',extraPhoneHtml('',Date.now(),''))}
function newClient(){form(-1)}function editClient(i){if(i>=0)form(i)}
function saveClient(i){
 const get = id => document.getElementById(id);
 const extra=[...document.querySelectorAll('.extraContact')].map(box=>({name:(box.querySelector('.extraContactName')?.value||'').trim(),phone:phoneDigits(box.querySelector('.extraPhoneInput')?.value||'')})).filter(x=>x.phone.length===11 || x.name);
 const cs=[...document.querySelectorAll('.car:checked')].map(x=>x.value);
 const client={number:i<0 ? db.nextClientNumber : db.clients[i].number,name:get('name').value.trim(),phone:(phoneDigits(get('phone').value).length===11 ? phoneDigits(get('phone').value) : ''),extraPhones:extra,address:(get('address')?.value||db.clients[i]?.address||'').trim(),model:get('model').value,cartridges:cs,install:get('install').value,replace:(get('serviceNextDate')?.value||''),notes:get('notes').value.trim(),serviceHistory: i<0 ? [] : (Array.isArray(db.clients[i].serviceHistory)?db.clients[i].serviceHistory:[]),completedDates: i<0 ? [] : (Array.isArray(db.clients[i].completedDates)?db.clients[i].completedDates:[])};
 if(!client.name && !client.phone){alert('Введите имя клиента или номер телефона.');return;}
 if(i<0){db.clients.push(client);db.nextClientNumber++;}else{db.clients[i]=client;}
 try{localStorage.setItem(KEY,JSON.stringify(db));clients();}catch(e){alert('Не удалось сохранить клиента: '+e.message);}
}

function addServiceRow(){document.getElementById('serviceRows').insertAdjacentHTML('beforeend',`<div class="grid serviceRow"><div><label>Картридж</label><select class="servicePart">${cartridges.map(x=>`<option>${x}</option>`).join('')}</select></div><div><label>Производитель</label><select class="serviceBrand">${brands.map(x=>`<option>${x}</option>`).join('')}</select></div></div>`)}
function addServiceRecord(i){
 if(i<0){alert('Сначала сохраните клиента.');return;}
 const rows=[...document.querySelectorAll('.serviceRow')];
 if(!rows.length){alert('Добавьте хотя бы один картридж.');return;}
 const date=document.getElementById('serviceDate').value||todayISO();
 const nextDate=document.getElementById('serviceNextDate').value||'';
 const comment=(document.getElementById('serviceComment').value||'').trim();
 const items=rows.map(r=>({part:r.querySelector('.servicePart').value,brand:r.querySelector('.serviceBrand').value}));
 if(!Array.isArray(db.clients[i].serviceHistory))db.clients[i].serviceHistory=[];
 db.clients[i].serviceHistory.push({date,nextDate,items,comment,completed:true});
 if(nextDate)db.clients[i].replace=nextDate;
 save();
 form(i);
}
function returnToClient(i){
 event?.preventDefault?.();
 event?.stopPropagation?.();
 form(i);
 return false;
}
function addEditServiceRow(part='',brand=''){
 const box=document.getElementById('editServiceRows');
 if(!box)return;
 box.insertAdjacentHTML('beforeend',`<div class="grid editServiceRow"><div><label>Картридж</label><select class="editServicePart">${cartridges.map(v=>`<option ${v===part?'selected':''}>${v}</option>`).join('')}</select></div><div><label>Производитель</label><select class="editServiceBrand">${brands.map(v=>`<option ${v===brand?'selected':''}>${v}</option>`).join('')}</select></div><button type="button" class="removeEditRow" onclick="this.parentElement.remove()">−</button></div>`);
}
function returnToHistoryList(i){
 const idx=Number(i);
 if(Number.isInteger(idx) && idx>=0 && idx<db.clients.length){
  serviceHistoryList(idx);
 }
 return false;
}
function returnToClientCard(i){
 const idx=Number(i);
 if(Number.isInteger(idx) && idx>=0 && idx<db.clients.length){
  form(idx);
 }
 return false;
}
function showServiceHistory(i,hIndex){
 setScreen('serviceDetail');
 const c=db.clients[i];
 if(!c||!Array.isArray(c.serviceHistory)||!c.serviceHistory[hIndex])return;
 const h=c.serviceHistory[hIndex];
 const items=Array.isArray(h.items)?h.items:[];
 app.innerHTML=`<div class="card"><div class="row"><div><div class="sectionTitle">Обслуживание от ${ruDate(h.date)}</div></div><button type="button" class="secondary" onclick="returnToHistoryList(${i})">Назад</button></div>
 <label>Дата замены</label><input id="editServiceDate" type="date" value="${h.date||''}">
 <label>Дата следующей замены</label><input id="editServiceNextDate" type="date" value="${h.nextDate||''}">
 <div style="margin-top:10px"><div class="sectionTitle">Картриджи</div><div id="editServiceRows"></div></div>
 <label>Комментарий</label><textarea id="editServiceComment" rows="4" placeholder="Что сделали, замечания">${esc(h.comment||'')}</textarea>
 <button type="button" class="secondary small" onclick="addEditServiceRow()">+ Добавить картридж</button>
 <button type="button" onclick="saveServiceHistory(${i},${hIndex})">Сохранить изменения</button>
 <button type="button" class="secondary" onclick="returnToHistoryList(${i})">Назад</button></div>`;
 items.forEach(x=>addEditServiceRow(x.part||'',x.brand||''));
 if(!items.length)addEditServiceRow();
}
function saveServiceHistory(i,hIndex){
 const c=db.clients[i],h=c&&c.serviceHistory&&c.serviceHistory[hIndex];
 if(!h)return;
 const date=document.getElementById('editServiceDate').value||h.date;
 const nextDate=document.getElementById('editServiceNextDate').value||'';
 const rows=[...document.querySelectorAll('.editServiceRow')];
 h.date=date;h.nextDate=nextDate;h.items=rows.map(r=>({part:r.querySelector('.editServicePart').value,brand:r.querySelector('.editServiceBrand').value}));
 h.comment=(document.getElementById('editServiceComment').value||'').trim();
 if(nextDate)c.replace=nextDate;
 save();
 form(i);
}
function deleteClient(i){if(confirm('Удалить клиента №'+db.clients[i].number+'?')){db.clients.splice(i,1);save();clients()}}
function toIntlPhone(phone){const p=phoneDigits(phone);return p.length===11&&p.startsWith('8')?'7'+p.slice(1):p;}
function callPhoneValue(phone){const dial=toIntlPhone(phone);if(!dial)return;if(window.Android&&Android.call){Android.call(dial);}else{location.href='tel:'+dial;}}
function waPhoneValue(phone){const waNumber=toIntlPhone(phone);if(!waNumber)return;if(window.Android)Android.whatsapp(waNumber);else{location.href='https://wa.me/'+waNumber;}}
function callExtraContact(index){const boxes=[...document.querySelectorAll('.extraContact')];const box=boxes[index];if(box)callPhoneValue(box.querySelector('.extraPhoneInput')?.value||'');}
function waExtraContact(index){const boxes=[...document.querySelectorAll('.extraContact')];const box=boxes[index];if(box)waPhoneValue(box.querySelector('.extraPhoneInput')?.value||'');}
function calendar(){
 setScreen('calendar');
 const y=month.getFullYear(),m=month.getMonth(),first=new Date(y,m,1),days=new Date(y,m+1,0).getDate(),offset=(first.getDay()+6)%7;
 let h=`<div class="calendarCard"><div class="row" style="margin-bottom:8px"><div class="sectionTitle">Выберите дату</div><button type="button" class="secondary" onclick="home()">Назад</button></div><div class="calhead row"><button onclick="month.setMonth(month.getMonth()-1);calendar()">‹</button><b>${month.toLocaleDateString('ru-RU',{month:'long',year:'numeric'})}</b><button onclick="month.setMonth(month.getMonth()+1);calendar()">›</button></div><div class="week">${['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(x=>`<div>${x}</div>`).join('')}</div><div class="calendar">`;
 for(let i=0;i<offset;i++)h+='<div></div>';
 for(let d=1;d<=days;d++){let ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,arr=db.clients.filter(c=>c.replace===ds&&!(c.completedDates||[]).includes(ds)),today=new Date(),isToday=today.getFullYear()===y&&today.getMonth()===m&&today.getDate()===d;h+=`<div class="day ${arr.length?'has':''} ${isToday?'today':''}" onclick="showDate('${ds}')"><span class="dayNum">${d}</span>${arr.length?`<span class=count>${arr.length}</span>`:''}</div>`}
 h+='</div></div>';app.innerHTML=h;
}
function showDate(ds){
 setScreen('date');const arr=db.clients.filter(c=>c.replace===ds);app.innerHTML=`<div class="card"><div class="row"><div class="sectionTitle">Заявки на ${ruDate(ds)}</div><button type="button" class="secondary" onclick="home()">Назад</button></div>${arr.length?arr.map(c=>`<div class="list"><div onclick="editClientByNumber(${c.number})"><b>№${c.number} — ${esc(c.name)}</b><div class="muted">📞 ${esc(c.phone)} · 🏠 ${esc(c.address)||'—'}</div></div></div>`).join(''):'<div class="empty">На эту дату замен нет.</div>'}</div>`}
function backup(){
 setScreen('backup');app.innerHTML=`<div class="card"><div class="row"><div class="sectionTitle">Резервная копия</div><button type="button" class="secondary" onclick="home()">Назад</button></div><p class="muted">Сохраняется вся клиентская база, номера клиентов, телефоны, адреса, фильтры, картриджи и даты.</p><button onclick="Android.backup(JSON.stringify(db))">Сохранить резервную копию</button><button class="secondary" onclick="Android.restore()">Восстановить из файла</button></div>`}
function restoreBackup(s){try{const x=JSON.parse(s);if(!x||!Array.isArray(x.clients))throw 0;db=x;db.clients.forEach(c=>{delete c.mineralizer;delete c.postfilter;delete c.pp100;});if(!Number.isInteger(db.nextClientNumber))db.nextClientNumber=db.clients.reduce((m,c)=>Math.max(m,Number(c.number)||0),0)+1;save();filterHome();alert('База восстановлена')}catch(e){alert('Не удалось восстановить резервную копию')}}
let currentScreen='hub';
let androidBackStack=[];
let restoringAndroidBack=false;
function setScreen(name){
 if(name===currentScreen)return;
 if(!restoringAndroidBack){
  const header=document.querySelector('header');
  const counters=document.getElementById('homeCounters');
  const fab=document.querySelector('.fab');
  androidBackStack.push({screen:currentScreen,html:app.innerHTML,headerDisplay:header?header.style.display:'',countersDisplay:counters?counters.style.display:'',countersClass:counters?counters.className:'',fabDisplay:fab?fab.style.display:''});
 }
 currentScreen=name;
}
function restoreAndroidBackSnapshot(snap){
 restoringAndroidBack=true;currentScreen=snap.screen;app.innerHTML=snap.html;
 const header=document.querySelector('header'),counters=document.getElementById('homeCounters'),fab=document.querySelector('.fab');
 if(header)header.style.display=snap.headerDisplay||'';
 if(counters){counters.style.display=snap.countersDisplay||'';counters.className=snap.countersClass||counters.className;}
 if(fab)fab.style.display=snap.fabDisplay||'';
 restoringAndroidBack=false;
}
function handleAndroidBack(){if(androidBackStack.length){restoreAndroidBackSnapshot(androidBackStack.pop());return 'handled';}return 'exit';}
function setShell(mode){const header=document.querySelector('header'),counters=document.getElementById('homeCounters'),fab=document.querySelector('.fab');const hub=mode==='hub',finance=mode==='income';const filters=mode==='filters';document.body.classList.toggle('hubMode',hub);document.body.classList.toggle('financeMode',finance);document.body.classList.toggle('filtersMode',filters);if(header)header.style.display=(hub||finance)?'none':'';if(counters)counters.style.display=filters?'':'none';if(fab)fab.style.display=filters?'':'none';}
function mainHome(){androidBackStack=[];restoringAndroidBack=true;currentScreen='hub';restoringAndroidBack=false;closeMenu();const counters=document.getElementById('homeCounters');const fab=document.querySelector('.fab');const header=document.querySelector('header');if(counters){counters.style.display='none';counters.classList.remove('open');}if(fab)fab.style.display='none';if(header)header.style.display='none';setShell('hub');app.innerHTML=`<div class="mainHub"><div class="hubTitle">Мои дела</div><div class="hubSub">Выберите нужный раздел</div><div class="hubGrid"><button type="button" class="hubTile filter" onclick="openFilters()"><span class="hubIcon"><svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#1565c0" d="M24 4C17 14 10 21 10 29a14 14 0 0 0 28 0C38 21 31 14 24 4Z"/><path fill="#fff" d="M17 28h14v3H17z"/></svg></span><span class="hubName">Мои фильтры</span><span class="hubHint">Клиенты · замены · заявки</span></button><button type="button" class="hubTile income" onclick="financeHome()"><span class="hubIcon"><svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#16834f" d="M8 12h28a4 4 0 0 1 4 4v20a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4V16a4 4 0 0 1 4-4Z"/><path fill="#fff" d="M32 22h8v10h-8a5 5 0 0 1 0-10Zm0 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/><path fill="#16834f" d="M9 7h24v5H9z"/></svg></span><span class="hubName">Доходы</span><span class="hubHint">Финансы · аналитика</span></button></div></div>`;}

function openFilters(){setShell('filters');filterHome();}
const FIN_KEY='moifiltry_finance_v2';
let financeDb=JSON.parse(localStorage.getItem(FIN_KEY)||'null');
if(!financeDb||!Array.isArray(financeDb.incomeSources)||!Array.isArray(financeDb.accounts)||!Array.isArray(financeDb.expenses)||!Array.isArray(financeDb.transactions)) financeDb={incomeSources:[],accounts:[],expenses:[],transactions:[]};
function financeSave(){localStorage.setItem(FIN_KEY,JSON.stringify(financeDb));}
function financeMoney(n){return Number(n||0).toLocaleString('ru-RU',{maximumFractionDigits:2})+' ₸';}
function financeMonth(){return todayISO().slice(0,7);}
let financeSelectedDate=todayISO();
function financeSum(list,kind,month){return list.filter(t=>t.kind===kind&&(!month||String(t.date||'').slice(0,7)===month)).reduce((a,t)=>a+Number(t.amount||0),0);}
function financeAccountBalance(id){let b=Number(financeDb.accounts.find(a=>a.id===id)?.balance||0);financeDb.transactions.forEach(t=>{if(t.kind==='income'&&t.accountId===id)b+=Number(t.amount||0);if(t.kind==='expense'&&t.accountId===id)b-=Number(t.amount||0);if(t.kind==='transfer'&&t.fromId===id)b-=Number(t.amount||0);if(t.kind==='transfer'&&t.toId===id)b+=Number(t.amount||0);});return b;}
function financeAccountSourceBalance(accountId,sourceId){let b=0;financeDb.transactions.forEach(t=>{const n=Number(t.amount||0);if(t.kind==='income'&&t.accountId===accountId&&t.sourceId===sourceId)b+=n;if(t.kind==='transfer'&&t.toId===accountId&&t.sourceId===sourceId)b+=n;if(t.kind==='transfer'&&t.fromId===accountId&&t.sourceId===sourceId)b-=n;});return b;}
function financeAccountSourceBreakdown(accountId){return financeDb.incomeSources.map(s=>({source:s,balance:financeAccountSourceBalance(accountId,s.id)})).filter(x=>x.balance>0.0001);}
function financeEnsureSourceForLegacyTransfer(t){if(t.kind==='transfer'&&!('sourceId' in t))t.sourceId='';return t;}
financeDb.transactions.forEach(financeEnsureSourceForLegacyTransfer);
function financeDefaultAccountId(){return financeDb.accounts.find(a=>String(a.name).toLowerCase().includes('кэш')||String(a.name).toLowerCase().includes('налич'))?.id||financeDb.accounts[0]?.id||'';}
function financeInit(){
 const old=JSON.parse(localStorage.getItem('moifiltry_income_v1')||'null');
 if(!financeDb.accounts.length) financeDb.accounts=[{id:'acc_default',name:'Кэш',icon:'₸',balance:0}];
 if(!financeDb.incomeSources.length) financeDb.incomeSources=[{id:'inc_default',name:'Технодом+',icon:'▣'}];
 if(!financeDb.expenses.length) financeDb.expenses=[{id:'exp_default',name:'Прочее',icon:'•',color:'green'}];
 if(old&&Array.isArray(old.sources)&&old.sources.length&&!financeDb.transactions.length){
  financeDb.incomeSources=old.sources.map((s,i)=>({id:'inc'+Date.now()+i,name:String(s.name||'Доход'),icon:'▣'}));
  old.sources.forEach((s,i)=>(s.entries||[]).forEach(e=>financeDb.transactions.push({id:'t'+Date.now()+Math.random(),kind:'income',sourceId:financeDb.incomeSources[i].id,accountId:financeDefaultAccountId(),amount:Number(e.amount||0),date:e.date||todayISO(),note:''})));
 }
 financeDb.incomeSources.forEach(x=>{if(String(x.name||'').trim()==='Технодом') x.name='Технодом+';});
 financeSave();
}
financeInit();
financeSelectedDate=todayISO();
function financeEscName(x){return esc(String(x||''));}
function financeCoinIcon(type,icon){const map={income:'▣',account:'₸',expense:'•'};return `<span style="font-size:27px;font-weight:700;line-height:1">${esc(icon||map[type]||'•')}</span>`;}
function financeCoin(type,item,amount,extra){
 const cls=type==='income'?'incomeCoin':type==='account'?'accountCoin':(item.color==='orange'?'expenseCoin orange':'expenseCoin');
 const fn=type==='income'?`financeSourceDetail('${item.id}')`:type==='account'?`financeAccountDetail('${item.id}')`:`financeExpenseDetail('${item.id}')`;
 const draggable=type==='income'?'data-drag="income"':type==='account'?'data-drag="account"':''; const drop=type==='account'?'data-drop-type="account"':type==='expense'?'data-drop-type="expense"':'';
 return `<div class="coinWrap"><div class="coinLabel" title="${financeEscName(item.name)}">${financeEscName(item.name)}</div><button type="button" class="coin ${cls}" ${draggable} data-id="${esc(item.id)}" ${drop} onclick="financeCoinClick(event,'${fn.replace(/'/g,"\\'")}')">${financeCoinIcon(type,item.icon)}</button><div class="coinAmount">${amount?financeMoney(amount):'—'}</div>${extra||''}</div>`;
}
function financeAddCoin(type,label){return `<div class="coinWrap"><div class="coinLabel">${label||''}</div><button type="button" class="coin addCoin" onclick="financeAdd('${type}')"><span class="plus">+</span></button><div class="coinAmount">Добавить</div></div>`;}
function financeMenuToggle(){document.getElementById('financeMenu')?.classList.toggle('open');}
function financeCloseMenu(){document.getElementById('financeMenu')?.classList.remove('open');}
function financeDrawerOpen(){document.getElementById('financeDrawer')?.classList.add('open');document.body.style.overflow='hidden';}
function financeDrawerClose(){document.getElementById('financeDrawer')?.classList.remove('open');document.body.style.overflow='';}
function financeDrawerGo(action){financeDrawerClose();if(action==='income')financeHome();else if(action==='overview')financeOverview();else if(action==='statistics')financeStatistics();else if(action==='history')financeHistory();}
function financeDrawerMarkup(){return `<div class="drawerShade" id="financeDrawer" onclick="if(event.target.id==='financeDrawer')financeDrawerClose()"><aside class="mainDrawer" aria-label="Финансовое меню"><div class="drawerHead"><button type="button" class="drawerClose" onclick="financeDrawerClose()" aria-label="Закрыть">×</button><div class="drawerTitle">Мои финансы</div><div class="drawerSub">Финансовое меню</div></div><div class="drawerBody"><button type="button" class="drawerItem" onclick="financeDrawerGo('income')"><span class="drawerIcon">₸</span><span>Доходы</span></button><button type="button" class="drawerItem" onclick="financeDrawerGo('overview')"><span class="drawerIcon">◔</span><span>Общее</span></button><button type="button" class="drawerItem" onclick="financeDrawerGo('statistics')"><span class="drawerIcon">▥</span><span>Статистика</span></button><button type="button" class="drawerItem" onclick="financeDrawerGo('history')"><span class="drawerIcon">☷</span><span>История</span></button></div></aside></div>`;}

function financeHeader(){return `<button type="button" class="drawerTopBtn financeDrawerTopBtn" onclick="financeDrawerOpen()" aria-label="Открыть финансовое меню">☰</button><div class="financeMenu" id="financeMenu"><button onclick="financeOverview();financeCloseMenu()">📊 Общие данные</button><button onclick="financeStatistics();financeCloseMenu()">📈 Статистика</button><button onclick="financeHistory();financeCloseMenu()">🧾 История</button></div>${financeDrawerMarkup()}`;}
function financeHome(){
 setScreen('income');setShell('income');
 const month=todayISO().slice(0,7);
 const incomes=financeDb.transactions.filter(t=>t.kind==='income'&&String(t.date).slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);
 const expenses=financeDb.transactions.filter(t=>t.kind==='expense'&&String(t.date).slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);
 const balance=financeDb.accounts.reduce((a,x)=>a+financeAccountBalance(x.id),0);
 const incomeCoins=financeDb.incomeSources.map(s=>{const sum=financeDb.transactions.filter(t=>t.kind==='income'&&t.sourceId===s.id&&String(t.date).slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);return financeCoin('income',s,sum)}).join('')+financeAddCoin('income','');
 const accountCoins=financeDb.accounts.map(a=>financeCoin('account',a,financeAccountBalance(a.id))).join('')+financeAddCoin('account','');
 const expenseCoins=financeDb.expenses.map(e=>{const sum=financeDb.transactions.filter(t=>t.kind==='expense'&&t.expenseId===e.id&&String(t.date).slice(0,7)===month).reduce((a,t)=>a+Number(t.amount||0),0);return financeCoin('expense',e,sum)}).join('')+financeAddCoin('expense','');
 app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeSummary"><div class="financeSummaryTop"><div class="financeSummaryMenu"><button type="button" class="financeMenuBtn" onclick="financeMenuToggle()" aria-label="Меню">⋮</button></div><div class="financeSummaryTitle">Баланс</div></div><div class="financeTop"><div class="financeStat balance"><b>${financeMoney(balance)}</b></div><div class="financeStat">Расходы<b>${financeMoney(expenses)}</b></div><div class="financeStat">Доходы<b>${financeMoney(incomes)}</b></div></div></div><div class="financeActionBar" style="display:flex"><button class="financeAction" onclick="financeOpenTransactionModal('income')">＋ Записать доход</button><button class="financeAction" onclick="financeOpenTransactionModal('expense')">− Записать расход</button></div><div class="financeSection"><div class="financeSectionTitle">Доходы</div><div class="financeRow" data-row="income">${incomeCoins}</div></div><div class="financeSection"><div class="financeSectionTitle">Кошельки / счета</div><div class="financeRow" data-row="account">${accountCoins}</div></div><div class="financeSection expenseSection"><div class="financeSectionTitle">Расходы</div><div class="financeRow" data-row="expense">${expenseCoins}</div></div></div>`;
 financeBindDrag();
}

function financeAdd(type){
 if(type==='income'){financeOpenAddSheet('income');return;}
 if(type==='account'){financeOpenAddSheet('account');return;}
 if(type==='expense'){financeOpenAddSheet('expense');return;}
 financeAddTransfer();
}
function financeOpenAddSheet(type){
 const titles={income:'Новый источник дохода',account:'Новый кошелёк / счёт',expense:'Новая категория расхода'};
 const defaults={income:'Технодом+',account:'Кэш',expense:'Еда'};
 const extra=type==='account'?'<label>Начальный баланс, ₸</label><input id="faBalance" inputmode="decimal" value="0">':'';
 document.body.insertAdjacentHTML('beforeend',`<div class="financeAddBack" id="financeAddBack" onclick="if(event.target.id==='financeAddBack')financeCloseAddSheet()"><div class="financeAddSheet"><div class="financeAddHead"><span>${titles[type]}</span><button type="button" class="secondary" onclick="financeCloseAddSheet()">✕</button></div><label>Название</label><input id="faName" value="${financeEscName(defaults[type])}" maxlength="60">${extra}<div class="financeAddButtons"><button type="button" class="secondary" onclick="financeCloseAddSheet()">Отмена</button><button type="button" onclick="financeSaveAddSheet('${type}')">Добавить</button></div></div></div>`);
 setTimeout(()=>document.getElementById('faName')?.focus(),50);
}
function financeCloseAddSheet(){document.getElementById('financeAddBack')?.remove();}
function financeSaveAddSheet(type){
 const name=String(document.getElementById('faName')?.value||'').trim();
 if(!name){return;}
 if(type==='income'){financeDb.incomeSources.push({id:'inc'+Date.now()+Math.random(),name,icon:'▣'});}
 if(type==='expense'){financeDb.expenses.push({id:'exp'+Date.now()+Math.random(),name,icon:'•',color:financeDb.expenses.length%3===0?'green':'orange'});}
 if(type==='account'){const raw=String(document.getElementById('faBalance')?.value||'0').replace(/[^0-9.,-]/g,'').replace(',','.');const b=Number(raw);if(!Number.isFinite(b)){return;}financeDb.accounts.push({id:'acc'+Date.now()+Math.random(),name,icon:'₸',balance:b});}
 financeSave();financeCloseAddSheet();financeHome();
}
function financeOpenTransactionModal(kind,pre){
 pre=pre||{};
 if(kind==='income'||kind==='expense') return financeOpenAmountSheet(kind,pre);
 let fields=`<label>Откуда</label><select id="fmFrom">${financeDb.accounts.map(x=>`<option value="${x.id}">${financeEscName(x.name)}</option>`).join('')}</select><label>Куда</label><select id="fmTo">${financeDb.accounts.map(x=>`<option value="${x.id}">${financeEscName(x.name)}</option>`).join('')}</select><label>Источник денег</label><select id="fmSource"><option value="">Общие деньги</option>${financeDb.incomeSources.map(x=>`<option value="${x.id}">${financeEscName(x.name)}</option>`).join('')}</select><label>Сумма, ₸</label><input id="fmAmount" inputmode="decimal" placeholder="1000"><label>Комментарий</label><input id="fmNote" placeholder="Необязательно">`;
 document.body.insertAdjacentHTML('beforeend',`<div class="financeModalBack" id="financeModalBack" onclick="if(event.target.id==='financeModalBack')financeCloseModal()"><div class="financeModal"><h3>Перевод</h3>${fields}<div class="modalButtons"><button class="secondary" onclick="financeCloseModal()">Отмена</button><button onclick="financeSaveModal('transfer')">Готово</button></div></div></div>`);
}
function financeOpenAmountSheet(kind,pre){
 const sourceId=pre.sourceId||'';const accountId=pre.accountId||financeDefaultAccountId();const expenseId=pre.expenseId||'';
 const source=financeDb.incomeSources.find(x=>x.id===sourceId);const account=financeDb.accounts.find(x=>x.id===accountId);const expense=financeDb.expenses.find(x=>x.id===expenseId);
 const from=kind==='income'?(source?.name||'Доход'):(account?.name||'Счёт');const to=kind==='income'?(account?.name||'Кэш'):(expense?.name||'Расход');
 document.body.insertAdjacentHTML('beforeend',`<div class="financeAmountBack" id="financeAmountBack" data-kind="${kind}" data-source="${esc(sourceId)}" data-account="${esc(accountId)}" data-expense="${esc(expenseId)}"><div class="financeAmountSheet"><div class="financeAmountHead"><button type="button" class="secondary" onclick="financeCloseAmountSheet()">✕</button><div class="financeAmountPath"><span>${financeEscName(from)}</span><b>›</b><span>${financeEscName(to)}</span></div><button type="button" onclick="financeCommitAmount()">✓</button></div><div id="financeAmountValue" class="financeAmountValue">0</div><div class="financeAmountCurrency">KZT</div><div class="financeKeypad">${['1','2','3','4','5','6','7','8','9',',','0','⌫'].map(k=>`<button type="button" class="financeKey" onclick="financeKeyPress('${k}')">${k}</button>`).join('')}</div><div class="financeAmountDate"><button type="button" class="active">СЕГОДНЯ</button></div></div></div>`);
}
function financeKeyPress(k){const el=document.getElementById('financeAmountValue');if(!el)return;let v=el.textContent||'0';if(k==='⌫'){v=v.length>1?v.slice(0,-1):'0';}else if(k===','){if(!v.includes(','))v+=',';}else{v=(v==='0'?k:v+k);}el.textContent=v;}
function financeCloseAmountSheet(){document.getElementById('financeAmountBack')?.remove();}
function financeCommitAmount(){const box=document.getElementById('financeAmountBack');const raw=document.getElementById('financeAmountValue')?.textContent||'0';const amount=Number(raw.replace(/\s/g,'').replace(',','.'));if(!Number.isFinite(amount)||amount<=0){alert('Введите сумму.');return;}const kind=box.dataset.kind;const t={id:'t'+Date.now()+Math.random(),kind,amount,date:todayISO(),note:''};if(kind==='income'){t.sourceId=box.dataset.source;t.accountId=box.dataset.account;}else{t.accountId=box.dataset.account;t.expenseId=box.dataset.expense;}financeDb.transactions.push(t);financeSave();financeCloseAmountSheet();financeHome();}
function financeCloseModal(){document.getElementById('financeModalBack')?.remove();}
function financeSaveModal(kind){const amount=Number(String(document.getElementById('fmAmount')?.value||'').replace(/[^0-9.,-]/g,'').replace(',','.'));if(!Number.isFinite(amount)||amount<=0){alert('Введите корректную сумму.');return;}const note=document.getElementById('fmNote')?.value||'';const t={id:'t'+Date.now()+Math.random(),kind,amount,date:todayISO(),note};if(kind==='transfer'){t.fromId=document.getElementById('fmFrom').value;t.toId=document.getElementById('fmTo').value;t.sourceId=document.getElementById('fmSource')?.value||'';if(t.fromId===t.toId){alert('Выберите разные счета.');return;}if(t.sourceId){const available=financeAccountSourceBalance(t.fromId,t.sourceId);if(available+0.0001<amount){alert('На выбранном счёте нет такой суммы этого источника.');return;}}}financeDb.transactions.push(t);financeSave();financeCloseModal();financeHome();}
function financeRowsForDate(rows){const ds=financeSelectedDate||todayISO();return rows.filter(t=>String(t.date||'')===ds);}
function financeAddTransfer(){if(financeDb.accounts.length<2){alert('Сначала создайте минимум два счёта.');return;}financeOpenTransactionModal('transfer');}
function financeBindDrag(){document.querySelectorAll('[data-drag]').forEach(el=>{el.addEventListener('pointerdown',financePointerDown,{passive:false});});}
let financeDrag=null;let financeSuppressClick=false;
function financePointerDown(e){
 if(e.button!==undefined&&e.button!==0)return;
 const el=e.currentTarget;
 const data={type:el.dataset.drag,id:el.dataset.id,startX:e.clientX,startY:e.clientY,pointerId:e.pointerId,dragging:false,ghost:null,target:null};
 financeDrag=data;
 const startDrag=(ev)=>{
  if(!financeDrag||data.dragging)return;
  data.dragging=true;
  try{el.setPointerCapture?.(data.pointerId);}catch(_){ }
  const ghost=el.cloneNode(true);
  ghost.classList.add('financeDragGhost');
  ghost.style.background=getComputedStyle(el).background;
  ghost.style.left=ev.clientX+'px';ghost.style.top=ev.clientY+'px';
  document.body.appendChild(ghost);data.ghost=ghost;el.classList.add('dragTarget');
 };
 const move=ev=>{
  if(!financeDrag)return;
  const dx=ev.clientX-data.startX,dy=ev.clientY-data.startY,dist=Math.hypot(dx,dy);
  if(!data.dragging&&dist>8) startDrag(ev);
  if(data.dragging){
   ev.preventDefault();
   data.ghost.style.left=ev.clientX+'px';data.ghost.style.top=ev.clientY+'px';
   document.querySelectorAll('.financeDropActive').forEach(x=>x.classList.remove('financeDropActive'));
   const target=document.elementsFromPoint(ev.clientX,ev.clientY).find(x=>x.dataset?.dropType);
   if(target){data.target=target;target.classList.add('financeDropActive');}else data.target=null;
  }
 };
 const cleanup=()=>{el.removeEventListener('pointermove',move);el.removeEventListener('pointerup',up);el.removeEventListener('pointercancel',up);document.querySelectorAll('.financeDropActive').forEach(x=>x.classList.remove('financeDropActive'));el.classList.remove('dragTarget');data.ghost?.remove();};
 const up=ev=>{
  if(!financeDrag)return;
  const d=financeDrag;financeDrag=null;cleanup();
  if(!d.dragging){return;}
  ev.preventDefault();
  financeSuppressClick=true;setTimeout(()=>financeSuppressClick=false,400);
  if(!d.target)return;
  const target=d.target;
  if(d.type==='income'&&target.dataset.dropType==='account')financeOpenAmountSheet('income',{sourceId:d.id,accountId:target.dataset.id});
  else if(d.type==='account'&&target.dataset.dropType==='expense')financeOpenAmountSheet('expense',{accountId:d.id,expenseId:target.dataset.id});
  else if(d.type==='account'&&target.dataset.dropType==='account'&&target.dataset.id!==d.id){
   const from=d.id,to=target.dataset.id;
   financeOpenTransactionModal('transfer');
   setTimeout(()=>{
    const f=document.getElementById('fmFrom'),t=document.getElementById('fmTo'),s=document.getElementById('fmSource');
    if(f)f.value=from;if(t)t.value=to;
    if(s){const src=financeAccountSourceBreakdown(from);if(src.length===1)s.value=src[0].source.id;}
   },0);
  }
 };
 el.addEventListener('pointermove',move,{passive:false});el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);
}
function financeCoinClick(event,action){if(financeSuppressClick){event.preventDefault();event.stopPropagation();return;}eval(action)}
function financeDropMarkup(type,item){return ''}
function financeSourceDetail(id){const s=financeDb.incomeSources.find(x=>x.id===id);if(!s)return;setScreen('financeSource');setShell('income');const all=financeDb.transactions.filter(t=>t.kind==='income'&&t.sourceId===id);const rows=all.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));const total=all.reduce((a,t)=>a+Number(t.amount||0),0);app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeDetail"><div class="financeDetailHead"><div class="financeDetailTitle">${financeEscName(s.name)}</div></div><div class="financeDetailAmount">${financeMoney(total)}</div><button onclick="financeOpenTransactionModal('income',{sourceId:'${id}',accountId:financeDefaultAccountId()})">＋ Записать доход</button><button class="danger small" onclick="financeDeleteSource('${id}')">Удалить</button></div><div class="financeDetail"><div class="sectionTitle">Операции</div><div class="financeList">${rows.length?rows.map(t=>`<div class="financeListRow"><div><div class="name financeIncome">Доход</div><div class="meta">${ruDate(t.date)}${t.note?' · '+financeEscName(t.note):''}</div></div><div class="sum financeIncome">+${financeMoney(t.amount)}</div></div>`).join(''):'<div class="financeEmpty">Операций пока нет.</div>'}</div></div></div>`;}
function financeAccountDetail(id){const a=financeDb.accounts.find(x=>x.id===id);if(!a)return;setScreen('financeAccount');setShell('income');const all=financeDb.transactions.filter(t=>t.accountId===id||t.fromId===id||t.toId===id);const rows=all.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));const sourceRows=financeAccountSourceBreakdown(id).map(x=>`<div class="financeAnalyticsRow"><span>${financeEscName(x.source.name)}</span><b>${financeMoney(x.balance)}</b></div>`).join('');app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeDetail"><div class="financeDetailHead"><div class="financeDetailTitle">${financeEscName(a.name)}</div></div><div class="financeDetailAmount">${financeMoney(financeAccountBalance(id))}</div><button onclick="financeOpenTransactionModal('income',{accountId:'${id}'})">＋ Доход</button><button onclick="financeOpenTransactionModal('expense',{accountId:'${id}'})">− Расход</button></div>${sourceRows?`<div class="financeDetail"><div class="sectionTitle">Из каких источников деньги</div>${sourceRows}</div>`:''}<div class="financeDetail"><div class="sectionTitle">Операции</div><div class="financeList">${rows.length?rows.map(t=>{let label=t.kind==='income'?(financeDb.incomeSources.find(x=>x.id===t.sourceId)?.name||'Доход'):t.kind==='expense'?'Расход':'Перевод';if(t.kind==='transfer'&&t.sourceId){const sn=financeDb.incomeSources.find(x=>x.id===t.sourceId)?.name;label=`Перевод · ${sn||'Источник'}`;}let sign=t.kind==='income'?'+':t.kind==='expense'?'−':(t.toId===id?'+':'−');let cls=t.kind==='income'?'financeIncome':t.kind==='expense'?'financeExpense':'financeTransfer';return `<div class="financeListRow"><div><div class="name ${cls}">${financeEscName(label)}</div><div class="meta">${ruDate(t.date)}${t.note?' · '+financeEscName(t.note):''}</div></div><div class="sum ${cls}">${sign}${financeMoney(t.amount)}</div></div>`}).join(''):'<div class="financeEmpty">Операций пока нет.</div>'}</div></div></div>`;}
function financeExpenseDetail(id){const e=financeDb.expenses.find(x=>x.id===id);if(!e)return;setScreen('financeExpense');const rows=financeDb.transactions.filter(t=>t.kind==='expense'&&t.expenseId===id).slice().reverse();const total=rows.reduce((a,t)=>a+Number(t.amount||0),0);app.innerHTML=`<div class="financeDetail"><div class="financeDetailHead"><div class="financeDetailTitle">${financeEscName(e.name)}</div></div><div class="financeDetailAmount">${financeMoney(total)}</div><button onclick="financeOpenTransactionModal('expense',{expenseId:'${id}'})">− Записать расход</button><button class="danger small" onclick="financeDeleteExpense('${id}')">Удалить</button></div><div class="financeDetail"><div class="sectionTitle">Операции</div><div class="financeList">${rows.length?rows.map(t=>`<div class="financeListRow"><div><div class="name financeExpense">Расход</div><div class="meta">${ruDate(t.date)}${t.note?' · '+financeEscName(t.note):''}</div></div><div class="sum financeExpense">−${financeMoney(t.amount)}</div></div>`).join(''):'<div class="financeEmpty">Пока нет операций.</div>'}</div></div>`;}
function financeDeleteSource(id){if(!confirm('Удалить источник дохода?'))return;financeDb.incomeSources=financeDb.incomeSources.filter(x=>x.id!==id);financeDb.transactions=financeDb.transactions.filter(t=>t.sourceId!==id);financeSave();financeHome();}
function financeDeleteExpense(id){if(!confirm('Удалить категорию расхода?'))return;financeDb.expenses=financeDb.expenses.filter(x=>x.id!==id);financeDb.transactions=financeDb.transactions.filter(t=>t.expenseId!==id);financeSave();financeHome();}
function financeHistory(){setScreen('financeHistory');setShell('income');const rows=financeDb.transactions.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeDetail"><div class="financeDetailHead"><div class="financeDetailTitle">История операций</div></div><div class="financeList">${rows.length?rows.slice(0,200).map(t=>{const s=financeDb.incomeSources.find(x=>x.id===t.sourceId)?.name;const e=financeDb.expenses.find(x=>x.id===t.expenseId)?.name;const a=financeDb.accounts.find(x=>x.id===t.accountId)?.name;const from=financeDb.accounts.find(x=>x.id===t.fromId)?.name;const to=financeDb.accounts.find(x=>x.id===t.toId)?.name;const label=t.kind==='income'?s||'Доход':t.kind==='expense'?e||'Расход':(from||'Счёт')+' → '+(to||'Счёт');const sign=t.kind==='income'?'+':t.kind==='expense'?'−':'⇄';const cls=t.kind==='income'?'financeIncome':t.kind==='expense'?'financeExpense':'financeTransfer';return `<div class="financeListRow"><div><div class="name ${cls}">${financeEscName(label)}</div><div class="meta">${ruDate(t.date)}${a?' · '+financeEscName(a):''}${t.note?' · '+financeEscName(t.note):''}</div></div><div class="sum ${cls}">${sign}${financeMoney(t.amount)}</div></div>`}).join(''):'<div class="financeEmpty">Операций пока нет.</div>'}</div></div></div>`;}
let financeOverviewYear=new Date().getFullYear();
function financeOverview(){
 setScreen('financeOverview');setShell('income');
 const year=financeOverviewYear;const tx=financeDb.transactions;
 const monthNames=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
 const cards=[];
 for(let i=0;i<12;i++){
  const ym=`${year}-${String(i+1).padStart(2,'0')}`;
  const monthTx=tx.filter(t=>String(t.date||'').slice(0,7)===ym);
  const income=monthTx.filter(t=>t.kind==='income').reduce((a,t)=>a+Number(t.amount||0),0);
  const expense=monthTx.filter(t=>t.kind==='expense').reduce((a,t)=>a+Number(t.amount||0),0);
  const totals={};monthTx.filter(t=>t.kind==='income').forEach(t=>{const n=financeDb.incomeSources.find(x=>x.id===t.sourceId)?.name||'Доход';totals[n]=(totals[n]||0)+Number(t.amount||0);});
  const rows=Object.entries(totals).sort((a,b)=>b[1]-a[1]).map(([n,v])=>{const pct=income?Math.round(v/income*1000)/10:0;return `<div class="financePctRow"><span>${financeEscName(n)}</span><b>${financeMoney(v)} · ${pct}%</b></div><div class="financePctBar"><span style="width:${Math.min(100,pct)}%"></span></div>`}).join('');
  cards.push(`<div class="financeMonthCard"><div class="financeMonthHead"><span>${monthNames[i]}</span><span>+${financeMoney(income)}</span></div><div class="financeAnalyticsRow"><span>Расходы</span><b>−${financeMoney(expense)}</b></div>${rows||'<div class="financeYearEmpty">Доходов за этот месяц пока нет.</div>'}</div>`);
 }
 const totalIncome=tx.filter(t=>String(t.date||'').startsWith(String(year))&&t.kind==='income').reduce((a,t)=>a+Number(t.amount||0),0);
 const totalExpense=tx.filter(t=>String(t.date||'').startsWith(String(year))&&t.kind==='expense').reduce((a,t)=>a+Number(t.amount||0),0);
 app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeAnalytics"><div class="financeAnalyticsCard"><div class="financeMonthHead"><span>Общее за ${year}</span><b>${financeMoney(totalIncome-totalExpense)}</b></div><div class="financeAnalyticsRow"><span>Доходы</span><b class="financeIncome">${financeMoney(totalIncome)}</b></div><div class="financeAnalyticsRow"><span>Расходы</span><b class="financeExpense">${financeMoney(totalExpense)}</b></div></div><div class="financeYearNav"><button onclick="financeOverviewYear--;financeOverview()">‹</button><span class="financeYearLabel">${year}</span><button onclick="financeOverviewYear++;financeOverview()">›</button></div>${cards.join('')}</div></div>`;
}
function financeStatistics(){setScreen('financeStatistics');setShell('income');const tx=financeDb.transactions;const totalIncome=tx.filter(t=>t.kind==='income').reduce((a,t)=>a+Number(t.amount||0),0);const totalExpense=tx.filter(t=>t.kind==='expense').reduce((a,t)=>a+Number(t.amount||0),0);const sourceRows=financeDb.incomeSources.map(s=>{const sum=tx.filter(t=>t.kind==='income'&&t.sourceId===s.id).reduce((a,t)=>a+Number(t.amount||0),0);return `<div class="financeAnalyticsRow"><span>${financeEscName(s.name)}</span><b>${financeMoney(sum)}</b></div>`}).join('');const accountRows=financeDb.accounts.map(a=>`<div class="financeAnalyticsRow"><span>${financeEscName(a.name)}</span><b>${financeMoney(financeAccountBalance(a.id))}</b></div>`).join('');app.innerHTML=`<div class="financePage">${financeHeader()}<div class="financeAnalytics"><div class="financeAnalyticsCard"><div class="financeAnalyticsTitle">Итоги</div><div class="financeAnalyticsRow"><span>Всего доходов</span><b class="financeIncome">${financeMoney(totalIncome)}</b></div><div class="financeAnalyticsRow"><span>Всего расходов</span><b class="financeExpense">${financeMoney(totalExpense)}</b></div><div class="financeAnalyticsRow"><span>Разница</span><b>${financeMoney(totalIncome-totalExpense)}</b></div></div><div class="financeAnalyticsCard"><div class="financeAnalyticsTitle">По источникам дохода</div>${sourceRows||'<div class="financeEmpty">Данных пока нет.</div>'}</div><div class="financeAnalyticsCard"><div class="financeAnalyticsTitle">По кошелькам / счетам</div>${accountRows||'<div class="financeEmpty">Счетов пока нет.</div>'}</div></div></div>`;}

initTopDate();
setInterval(()=>{initTopDate();updateHomeCounters();},60000);
mainHome();
